# وصفاتي (Wasfati)
Clean Architecture + MVVM
- data/remote  : Retrofit + DTOs
- data/local   : Room (favorites, shopping, api_cache, translations)
- domain       : models + repository interfaces
- presentation : Compose screens + ViewModels
- di           : Hilt modules
انسخ local.properties.example إلى local.properties وضع مفتاح Spoonacular.
