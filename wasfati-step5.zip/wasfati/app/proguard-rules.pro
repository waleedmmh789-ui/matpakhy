# Gson يقرأ/يكتب هذه الكلاسات بالأسماء (JSON من الـ API ومن Room)
-keep class com.example.wasfati.data.remote.dto.** { *; }
-keep class com.example.wasfati.domain.model.** { *; }
-keepattributes Signature, *Annotation*
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken

# Retrofit
-keepattributes Exceptions
-keep,allowobfuscation interface com.example.wasfati.data.remote.SpoonacularApi
-dontwarn retrofit2.**
-dontwarn okhttp3.**
-dontwarn okio.**
