package com.example.wasfati.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cooking_timers")
data class TimerEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val label: String,
    val recipeTitle: String,
    val stepKey: String,
    val totalSeconds: Int,
    val endAt: Long,
    val finished: Boolean = false
)
