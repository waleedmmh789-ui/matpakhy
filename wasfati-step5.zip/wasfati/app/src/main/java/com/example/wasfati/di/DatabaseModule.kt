package com.example.wasfati.di

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.wasfati.data.local.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun provideDb(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "wasfati.db")
            .addMigrations(MIGRATION_1_2)   // لا نفقد المفضلة وقائمة التسوق عند التحديث
            .build()

    @Provides fun favoriteDao(db: AppDatabase) = db.favoriteDao()
    @Provides fun shoppingDao(db: AppDatabase) = db.shoppingDao()
    @Provides fun cacheDao(db: AppDatabase) = db.cacheDao()
    @Provides fun translationDao(db: AppDatabase) = db.translationDao()
    @Provides fun timerDao(db: AppDatabase) = db.timerDao()
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `cooking_timers` (" +
            "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            "`label` TEXT NOT NULL, `recipeTitle` TEXT NOT NULL, `stepKey` TEXT NOT NULL, " +
            "`totalSeconds` INTEGER NOT NULL, `endAt` INTEGER NOT NULL, `finished` INTEGER NOT NULL)"
        )
    }
}
