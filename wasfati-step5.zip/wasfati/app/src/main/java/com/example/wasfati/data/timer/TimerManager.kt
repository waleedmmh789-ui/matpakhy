package com.example.wasfati.data.timer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.wasfati.MainActivity
import com.example.wasfati.data.local.dao.TimerDao
import com.example.wasfati.data.local.entity.TimerEntity
import com.example.wasfati.data.settings.SettingsRepository
import com.example.wasfati.domain.model.CookingTimer
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * يدير أكثر من مؤقت في نفس الوقت. كل مؤقت:
 *  - محفوظ في Room (يبقى بعد إغلاق التطبيق)
 *  - له منبّه في AlarmManager (يوقظ الجهاز حتى لو الشاشة مقفلة)
 *  - له إشعار بعدّاد تنازلي حي
 */
@Singleton
class TimerManager @Inject constructor(
    @ApplicationContext private val app: Context,
    private val dao: TimerDao,
    private val notifier: TimerNotifier,
    private val settings: SettingsRepository
) {
    val timers: Flow<List<CookingTimer>> = dao.observeAll().map { list -> list.map { it.toModel() } }

    suspend fun start(label: String, recipeTitle: String, seconds: Int, stepKey: String = ""): Int {
        if (stepKey.isNotEmpty()) {   // نفس الخطوة شغّالة بالفعل؟ لا نكرّرها
            dao.getAll().firstOrNull { it.stepKey == stepKey && !it.finished }?.let { return it.id }
        }
        val entity = TimerEntity(
            label = label, recipeTitle = recipeTitle, stepKey = stepKey,
            totalSeconds = seconds, endAt = System.currentTimeMillis() + seconds * 1000L
        )
        val id = dao.insert(entity).toInt()
        val saved = entity.copy(id = id)
        schedule(saved); notifier.showRunning(saved)
        return id
    }

    suspend fun addMinute(id: Int) {
        val t = dao.get(id) ?: return
        val (end, total) = if (t.finished || t.endAt <= System.currentTimeMillis())
            (System.currentTimeMillis() + 60_000L) to 60 else (t.endAt + 60_000L) to (t.totalSeconds + 60)
        dao.reschedule(id, end, total)
        val updated = t.copy(endAt = end, totalSeconds = total, finished = false)
        schedule(updated); notifier.showRunning(updated)
    }

    suspend fun cancel(id: Int) {
        alarmManager().cancel(firePi(id))
        notifier.cancel(id)
        dao.delete(id)
    }

    /** يُستدعى من المنبّه عند انتهاء الوقت */
    suspend fun onFired(id: Int) {
        val t = dao.get(id) ?: return          // أُلغي قبل الانتهاء
        if (t.finished || t.endAt > System.currentTimeMillis() + 1500) return   // مُدِّد بـ +1 دقيقة
        dao.markFinished(id)
        val s = settings.settings.first()
        notifier.showFinished(t, s.timerSound, s.timerVibration)
    }

    /** بعد إعادة تشغيل الهاتف تُمسح المنبّهات، فنعيد جدولتها */
    suspend fun rescheduleAll() {
        val now = System.currentTimeMillis()
        dao.getAll().filter { !it.finished }.forEach {
            if (it.endAt <= now) onFired(it.id) else { schedule(it); notifier.showRunning(it) }
        }
    }

    private fun alarmManager() = app.getSystemService(AlarmManager::class.java)

    private fun flags() = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun firePi(id: Int) = PendingIntent.getBroadcast(
        app, TimerActions.rc(id, TimerActions.K_FIRE),
        Intent(app, TimerReceiver::class.java).setAction(TimerActions.FIRE).putExtra(TimerActions.EXTRA_ID, id),
        flags()
    )

    /** setAlarmClock: دقيق ويعمل في وضع Doze بدون أذونات خاصة */
    private fun schedule(t: TimerEntity) {
        val show = PendingIntent.getActivity(
            app, TimerActions.rc(t.id, TimerActions.K_SHOW),
            Intent(app, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(TimerActions.EXTRA_OPEN_TIMERS, true)
            }, flags()
        )
        alarmManager().setAlarmClock(AlarmManager.AlarmClockInfo(t.endAt, show), firePi(t.id))
    }

    private fun TimerEntity.toModel() =
        CookingTimer(id, label, recipeTitle, stepKey, totalSeconds, endAt, finished)
}
