package com.example.wasfati.presentation.timer

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.wasfati.R

/** شريط صغير أسفل الشاشة يظهر أثناء وجود مؤقتات، ويفتح شاشة المؤقتات */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActiveTimersStrip(onOpen: () -> Unit, vm: TimersViewModel = hiltViewModel()) {
    val timers by vm.timers.collectAsStateWithLifecycle()
    if (timers.isEmpty()) return
    val now by rememberNow()
    val running = timers.filter { !it.finished && it.endAt > now }
    val done = timers.size - running.size
    val nearest = running.minByOrNull { it.endAt }
    val color = if (done > 0) Color(0xFFE53935) else MaterialTheme.colorScheme.primary

    Surface(onClick = onOpen, color = color) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Timer, null, tint = Color.White)
            Spacer(Modifier.width(10.dp))
            Text(
                if (done > 0) stringResource(R.string.timer_finished_title) else stringResource(R.string.timer_strip_fmt, timers.size),
                color = Color.White, modifier = Modifier.weight(1f)
            )
            nearest?.let {
                Text(formatClock(((it.endAt - now) / 1000).toInt().coerceAtLeast(0)), color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}
