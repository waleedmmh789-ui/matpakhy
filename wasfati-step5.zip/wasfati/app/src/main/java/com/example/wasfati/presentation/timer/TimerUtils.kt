package com.example.wasfati.presentation.timer

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import kotlinx.coroutines.delay
import java.util.Locale

data class StepTime(val seconds: Int, val text: String)

private val RX = Regex(
    """(\d+(?:\.\d+)?)\s*(?:(?:to|or|-|–|—|إلى|الى|او|أو)\s*(\d+(?:\.\d+)?)\s*)?(hours?|hrs?|minutes?|mins?|seconds?|secs?|ساعات|ساعة|دقائق|دقيقة|دقايق|ثواني|ثوان|ثانية)""",
    RegexOption.IGNORE_CASE
)

private fun normalizeDigits(s: String): String = buildString {
    for (ch in s) append(
        when (ch) {
            in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
            in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
            '\u066B', '\u060C' -> if (ch == '\u066B') '.' else ch
            else -> ch
        }
    )
}.replace(Regex("(\\d),(\\d)"), "$1.$2")

private fun unitSeconds(u: String) = when {
    u.startsWith("h") || u.startsWith("ساع") -> 3600
    u.startsWith("m") || u.startsWith("دق") -> 60
    else -> 1
}

/** يلتقط الأزمنة في نص الخطوة (إنجليزي أو عربي): "10 minutes" ، "من 10 إلى 12 دقيقة" ، "1 hour 30 minutes" */
fun parseStepTimes(raw: String): List<StepTime> {
    val s = normalizeDigits(raw)
    val out = mutableListOf<StepTime>()
    var prevEnd = -1
    var prevWasHour = false
    for (m in RX.findAll(s)) {
        val a = m.groupValues[1].toDoubleOrNull() ?: continue
        val b = m.groupValues[2].toDoubleOrNull()
        val unit = m.groupValues[3].lowercase()
        val mult = unitSeconds(unit)
        val sec = (maxOf(a, b ?: a) * mult).toInt()
        val gap = if (prevEnd >= 0) s.substring(prevEnd, m.range.first).trim().lowercase() else null
        if (prevWasHour && mult == 60 && out.isNotEmpty() && gap != null && gap in listOf("", "and", "و", ",", "،")) {
            val last = out.removeAt(out.lastIndex)       // ساعة + دقائق = مؤقت واحد
            out += StepTime(last.seconds + sec, last.text + " " + m.value.trim())
        } else out += StepTime(sec, m.value.trim())
        prevEnd = m.range.last + 1
        prevWasHour = mult == 3600
    }
    return out.filter { it.seconds in 5..86_400 }.distinctBy { it.seconds }.take(2)
}

fun formatClock(totalSeconds: Int): String {
    val h = totalSeconds / 3600; val m = (totalSeconds % 3600) / 60; val s = totalSeconds % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
}

/** ساعة تتحدّث كل ثانية لعرض العدّ التنازلي */
@Composable
fun rememberNow(): State<Long> = produceState(System.currentTimeMillis()) {
    while (true) { value = System.currentTimeMillis(); delay(1000) }
}
