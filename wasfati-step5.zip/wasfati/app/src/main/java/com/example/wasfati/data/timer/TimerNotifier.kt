package com.example.wasfati.data.timer

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.wasfati.MainActivity
import com.example.wasfati.R
import com.example.wasfati.data.local.entity.TimerEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TimerNotifier @Inject constructor(@ApplicationContext private val app: Context) {

    private val nm = NotificationManagerCompat.from(app)

    private companion object {
        const val CH_RUNNING = "timer_running"
        val VIBRATION = longArrayOf(0, 800, 400, 800, 400, 800, 400, 1200)
        fun doneChannel(sound: Boolean, vib: Boolean) = "timer_done_${if (sound) 1 else 0}${if (vib) 1 else 0}"
    }

    /** نصوص الإشعار بلغة التطبيق المختارة */
    private fun localized(): Context {
        val l = AppCompatDelegate.getApplicationLocales()
        if (l.isEmpty) return app
        val cfg = Configuration(app.resources.configuration).apply { setLocale(l[0]) }
        return app.createConfigurationContext(cfg)
    }

    private fun alarmUri() = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

    private fun flags() = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun contentPi(id: Int) = PendingIntent.getActivity(
        app, TimerActions.rc(id, TimerActions.K_CONTENT),
        Intent(app, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(TimerActions.EXTRA_OPEN_TIMERS, true)
        }, flags()
    )

    private fun stopPi(id: Int) = PendingIntent.getBroadcast(
        app, TimerActions.rc(id, TimerActions.K_STOP),
        Intent(app, TimerReceiver::class.java).setAction(TimerActions.STOP).putExtra(TimerActions.EXTRA_ID, id),
        flags()
    )

    private fun ensureChannels(c: Context, sound: Boolean, vib: Boolean) {
        if (Build.VERSION.SDK_INT < 26) return
        val running = NotificationChannel(CH_RUNNING, c.getString(R.string.timer_channel_running),
            NotificationManager.IMPORTANCE_LOW).apply { setSound(null, null); enableVibration(false) }
        val done = NotificationChannel(doneChannel(sound, vib), c.getString(R.string.timer_channel_done),
            NotificationManager.IMPORTANCE_HIGH).apply {
            if (sound) setSound(alarmUri(), AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)            // يعمل على صوت المنبّه حتى لو الهاتف صامت
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            else setSound(null, null)
            enableVibration(vib)
            if (vib) vibrationPattern = VIBRATION
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        app.getSystemService(NotificationManager::class.java).createNotificationChannels(listOf(running, done))
    }

    /** إشعار جارٍ بعدّاد تنازلي حي (لا يحتاج تحديثاً من التطبيق) */
    @SuppressLint("MissingPermission")
    fun showRunning(t: TimerEntity) {
        val c = localized(); ensureChannels(c, true, true)
        val n = NotificationCompat.Builder(c, CH_RUNNING)
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle(t.label)
            .setContentText(t.recipeTitle.ifBlank { c.getString(R.string.timers) })
            .setUsesChronometer(true).setChronometerCountDown(true)
            .setWhen(t.endAt).setShowWhen(true)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setContentIntent(contentPi(t.id))
            .addAction(0, c.getString(R.string.timer_cancel), stopPi(t.id))
            .build()
        if (nm.areNotificationsEnabled()) nm.notify(t.id, n)
    }

    /** إشعار الانتهاء: صوت منبّه متكرر + اهتزاز قوي حتى الإيقاف (أو دقيقتين) */
    @SuppressLint("MissingPermission")
    fun showFinished(t: TimerEntity, sound: Boolean, vib: Boolean) {
        val c = localized(); ensureChannels(c, sound, vib)
        val b = NotificationCompat.Builder(c, doneChannel(sound, vib))
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle(c.getString(R.string.timer_finished_title))
            .setContentText(t.label)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(contentPi(t.id))
            .setDeleteIntent(stopPi(t.id))
            .addAction(0, c.getString(R.string.timer_stop), stopPi(t.id))
            .setTimeoutAfter(120_000)
        if (Build.VERSION.SDK_INT < 26) {
            if (sound) b.setSound(alarmUri(), AudioManager.STREAM_ALARM)
            if (vib) b.setVibrate(VIBRATION)
        }
        val n = b.build().apply { flags = flags or Notification.FLAG_INSISTENT }
        if (nm.areNotificationsEnabled()) nm.notify(t.id, n)
    }

    fun cancel(id: Int) = nm.cancel(id)
}
