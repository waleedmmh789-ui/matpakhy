package com.example.wasfati.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.wasfati.R
import com.example.wasfati.domain.model.Recipe
import com.example.wasfati.presentation.theme.SuccessGreen
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    val c = MaterialTheme.colorScheme
    CenterAlignedTopAppBar(
        title = { Text(title) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
        actions = actions,
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = c.primary, titleContentColor = c.onPrimary,
            navigationIconContentColor = c.onPrimary, actionIconContentColor = c.onPrimary
        )
    )
}

@Composable
fun LoadingBox() = Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }

@Composable
fun MessageBox(text: String, actionLabel: String? = null, onAction: () -> Unit = {}) {
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        if (actionLabel != null) {
            Spacer(Modifier.height(12.dp))
            Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

/** بانر AdMob ثابت — المعرّف أدناه تجريبي، استبدله قبل النشر */
@Composable
fun BannerAd(modifier: Modifier = Modifier) {
    if (LocalInspectionMode.current) return
    AndroidView(
        modifier = modifier.fillMaxWidth().navigationBarsPadding(),
        factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = "ca-app-pub-3940256099942544/6300978111"
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}

@Composable
fun RecipeCard(
    recipe: Recipe, isFavorite: Boolean,
    onClick: () -> Unit, onFavorite: () -> Unit, extra: String? = null
) {
    Card(
        onClick = onClick, shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Box {
            AsyncImage(
                model = recipe.imageUrl, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(120.dp)
            )
            Box(
                Modifier.align(Alignment.TopEnd).padding(6.dp).size(34.dp).clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.92f)).clickable(onClick = onFavorite),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null,
                    tint = Color(0xFFE53935), modifier = Modifier.size(20.dp)
                )
            }
        }
        Column(Modifier.padding(10.dp)) {
            Text(
                recipe.title, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                recipe.calories?.let { Meta(Icons.Filled.LocalFireDepartment, Color(0xFFE65100), stringResource(R.string.kcal, it)) }
                recipe.readyInMinutes?.let { Meta(Icons.Filled.Schedule, Color(0xFF1E88E5), stringResource(R.string.minutes, it)) }
            }
            extra?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = SuccessGreen) }
        }
    }
}

@Composable
private fun Meta(icon: ImageVector, tint: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(3.dp))
        Text(text, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** شبكة عمودين مشتركة بين الرئيسية والمفضلة والمكتشف */
@Composable
fun RecipeGrid(
    recipes: List<Recipe>, favoriteIds: Set<Int>,
    onRecipe: (Int) -> Unit, onFavorite: (Recipe) -> Unit,
    modifier: Modifier = Modifier, state: LazyGridState = rememberLazyGridState(),
    extra: (Recipe) -> String? = { null }
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2), state = state, modifier = modifier,
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(recipes, key = { it.id }) { r ->
            RecipeCard(r, r.id in favoriteIds, { onRecipe(r.id) }, { onFavorite(r) }, extra(r))
        }
    }
}
