package com.example.wasfati.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** وصفة مفضلة: تُحفظ كاملة (مترجمة) لتعمل بدون إنترنت */
@Entity(tableName = "favorite_recipes")
data class FavoriteRecipeEntity(
    @PrimaryKey val id: Int,
    val title: String,
    val titleAr: String?,
    val imageUrl: String?,
    val calories: Int?,
    val readyInMinutes: Int?,
    val servings: Int?,
    val ingredientsJson: String,
    val stepsJson: String,
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "shopping_items",
    indices = [Index(value = ["recipeId", "name"], unique = true)]
)
data class ShoppingItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recipeId: Int,
    val recipeTitle: String,
    val name: String,
    val amount: Double?,
    val unit: String?,
    val isChecked: Boolean = false,
    val addedAt: Long = System.currentTimeMillis()
)

/** كاش استجابات الـ API (المفتاح = endpoint + المعاملات) */
@Entity(tableName = "api_cache")
data class CachedResponseEntity(
    @PrimaryKey val cacheKey: String,
    val json: String,
    val cachedAt: Long = System.currentTimeMillis()
)

/** ترجمات محفوظة محلياً لتجنّب إعادة الترجمة */
@Entity(tableName = "translations")
data class TranslationEntity(
    @PrimaryKey val sourceText: String,
    val translated: String
)
