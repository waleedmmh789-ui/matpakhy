package com.example.wasfati.presentation.settings

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wasfati.data.settings.AppSettings
import com.example.wasfati.data.settings.SettingsRepository
import com.example.wasfati.data.settings.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(private val repo: SettingsRepository) : ViewModel() {

    val settings = repo.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    fun setTheme(mode: ThemeMode) = viewModelScope.launch { repo.setThemeMode(mode) }
    fun setTimerSound(v: Boolean) = viewModelScope.launch { repo.setTimerSound(v) }
    fun setTimerVibration(v: Boolean) = viewModelScope.launch { repo.setTimerVibration(v) }

    fun setLanguage(tag: String) = viewModelScope.launch {
        repo.setLanguage(tag)
        // يعيد إنشاء الشاشة ويقلب الاتجاه RTL/LTR تلقائياً
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }
}
