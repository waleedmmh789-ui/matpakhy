package com.example.wasfati

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.wasfati.data.settings.AppSettings
import com.example.wasfati.data.settings.SettingsRepository
import com.example.wasfati.data.settings.ThemeMode
import com.example.wasfati.data.timer.TimerActions
import com.example.wasfati.presentation.navigation.AppNavHost
import com.example.wasfati.presentation.navigation.Routes
import com.example.wasfati.presentation.theme.WasfatiTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    @Inject lateinit var settingsRepo: SettingsRepository
    private val openTimers = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)
        setContent {
            val s: AppSettings? by settingsRepo.settings.collectAsStateWithLifecycle(null)
            val settings = s
            WasfatiTheme(settings?.themeMode ?: ThemeMode.SYSTEM) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (settings != null) {
                        val start = remember { if (settings.onboardingDone) Routes.HOME else Routes.ONBOARDING }
                        AppNavHost(start, openTimers.value) { openTimers.value = false }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(TimerActions.EXTRA_OPEN_TIMERS, false) == true) openTimers.value = true
    }
}
