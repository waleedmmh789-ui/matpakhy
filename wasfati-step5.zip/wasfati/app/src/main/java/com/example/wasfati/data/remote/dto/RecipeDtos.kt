package com.example.wasfati.data.remote.dto

import com.google.gson.annotations.SerializedName

data class NutrientDto(val name: String?, val amount: Double?, val unit: String?)
data class NutritionDto(val nutrients: List<NutrientDto>?) {
    val calories: Int? get() = nutrients?.firstOrNull { it.name == "Calories" }?.amount?.toInt()
}

/** استجابة complexSearch */
data class SearchResponseDto(
    val results: List<RecipeSummaryDto> = emptyList(),
    val offset: Int = 0,
    val number: Int = 0,
    val totalResults: Int = 0
)

data class RecipeSummaryDto(
    val id: Int,
    val title: String,
    val image: String?,
    val readyInMinutes: Int?,
    val servings: Int?,
    val nutrition: NutritionDto?
)

/** استجابة findByIngredients */
data class IngredientMatchDto(
    val id: Int,
    val title: String,
    val image: String?,
    val usedIngredientCount: Int = 0,
    val missedIngredientCount: Int = 0,
    val usedIngredients: List<IngredientRefDto> = emptyList(),
    val missedIngredients: List<IngredientRefDto> = emptyList()
)
data class IngredientRefDto(val id: Int?, val name: String?, val original: String?)

/** استجابة information */
data class RecipeDetailDto(
    val id: Int,
    val title: String,
    val image: String?,
    val readyInMinutes: Int?,
    val servings: Int?,
    val summary: String?,
    val instructions: String?,
    val extendedIngredients: List<ExtendedIngredientDto> = emptyList(),
    val analyzedInstructions: List<AnalyzedInstructionDto> = emptyList(),
    val nutrition: NutritionDto?
)

data class ExtendedIngredientDto(
    val id: Int?,
    val name: String?,
    val original: String?,
    val amount: Double?,
    val unit: String?,
    val image: String?,
    val measures: MeasuresDto?
)
data class MeasuresDto(val us: MeasureDto?, val metric: MeasureDto?)
data class MeasureDto(
    val amount: Double?,
    @SerializedName("unitShort") val unitShort: String?,
    @SerializedName("unitLong") val unitLong: String?
)

data class AnalyzedInstructionDto(val name: String?, val steps: List<StepDto> = emptyList())
data class StepDto(val number: Int, val step: String)
