package com.example.wasfati.presentation.details

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.text.TextUtils.htmlEncode
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.wasfati.domain.model.RecipeDetail

/** يفتح نافذة الطباعة في النظام — منها "حفظ كـ PDF" */
fun printRecipe(context: Context, d: RecipeDetail, rtl: Boolean) {
    val html = buildString {
        append("<html dir='${if (rtl) "rtl" else "ltr"}'><body style='font-family:sans-serif;padding:16px'>")
        append("<h1 style='color:#FF6D00'>${htmlEncode(d.title)}</h1>")
        d.imageUrl?.let { append("<img src='$it' style='max-width:100%;border-radius:12px'/>") }
        append("<ul>"); d.ingredients.forEach { append("<li>${htmlEncode(it.original)}</li>") }; append("</ul><ol>")
        d.steps.forEach { append("<li style='margin-bottom:8px'>${htmlEncode(it)}</li>") }
        append("</ol></body></html>")
    }
    val web = WebView(context)
    web.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String?) {
            val pm = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            pm.print(d.title, view.createPrintDocumentAdapter(d.title), PrintAttributes.Builder().build())
        }
    }
    web.loadDataWithBaseURL(null, html, "text/HTML", "UTF-8", null)
}
