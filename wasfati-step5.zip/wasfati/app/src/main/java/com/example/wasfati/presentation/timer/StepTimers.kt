package com.example.wasfati.presentation.timer

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.wasfati.R
import com.example.wasfati.domain.model.CookingTimer

/** أزرار المؤقت تحت نص الخطوة — تظهر فقط إذا كانت الخطوة تحتوي زمناً */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun StepTimers(
    recipeId: Int, stepIndex: Int, step: String, timers: List<CookingTimer>,
    onStart: (key: String, seconds: Int) -> Unit, onCancel: (Int) -> Unit
) {
    val times = remember(step) { parseStepTimes(step) }
    if (times.isEmpty()) return
    FlowRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        times.forEach { t ->
            val key = "$recipeId:$stepIndex:${t.seconds}"
            val running = timers.firstOrNull { it.stepKey == key }
            if (running == null) {
                AssistChip(
                    onClick = { onStart(key, t.seconds) },
                    label = { Text(stringResource(R.string.timer_start_fmt, t.text)) },
                    leadingIcon = { Icon(Icons.Filled.Timer, null, tint = MaterialTheme.colorScheme.primary) }
                )
            } else {
                val now by rememberNow()
                val left = ((running.endAt - now) / 1000).toInt()
                val done = running.finished || left <= 0
                AssistChip(
                    onClick = { onCancel(running.id) },
                    label = { Text(if (done) stringResource(R.string.timer_finished) else formatClock(left)) },
                    leadingIcon = { Icon(Icons.Filled.Timer, null, tint = if (done) Color(0xFFE53935) else MaterialTheme.colorScheme.primary) },
                    trailingIcon = { Icon(Icons.Filled.Close, null, Modifier.size(16.dp)) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = (if (done) Color(0xFFE53935) else MaterialTheme.colorScheme.primary).copy(alpha = 0.15f)
                    )
                )
            }
        }
    }
}
