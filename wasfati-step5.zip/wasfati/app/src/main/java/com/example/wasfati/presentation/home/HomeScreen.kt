package com.example.wasfati.presentation.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.wasfati.R
import com.example.wasfati.presentation.components.*
import com.example.wasfati.presentation.navigation.Routes
import com.example.wasfati.presentation.timer.ActiveTimersStrip
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onRecipe: (Int) -> Unit, onNavigate: (String) -> Unit, vm: HomeViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val favIds by vm.favoriteIds.collectAsStateWithLifecycle()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val gridState = rememberLazyGridState()
    var searching by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    val c = MaterialTheme.colorScheme

    val nearEnd by remember {
        derivedStateOf {
            val last = gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= gridState.layoutInfo.totalItemsCount - 4
        }
    }
    LaunchedEffect(nearEnd) { if (nearEnd) vm.loadMore() }
    LaunchedEffect(state.category, state.searchQuery) { gridState.scrollToItem(0) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineSmall,
                    color = c.primary, modifier = Modifier.padding(24.dp))
                Category.entries.forEach { cat ->
                    NavigationDrawerItem(
                        label = { Text(stringResource(cat.title)) },
                        icon = { Icon(Icons.Filled.Restaurant, null, tint = Color(0xFFFF6D00)) },
                        selected = cat == state.category && state.searchQuery == null,
                        onClick = { vm.selectCategory(cat); scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                DrawerLink(Icons.Filled.Timer, Color(0xFFFF6D00), R.string.timers) { onNavigate(Routes.TIMERS) }
                DrawerLink(Icons.Filled.Kitchen, Color(0xFF8E24AA), R.string.recipe_finder) { onNavigate(Routes.FINDER) }
                DrawerLink(Icons.Filled.Favorite, Color(0xFFE53935), R.string.favorites) { onNavigate(Routes.FAVORITES) }
                DrawerLink(Icons.Filled.ShoppingCart, Color(0xFF2E7D32), R.string.shopping_list) { onNavigate(Routes.SHOPPING) }
                DrawerLink(Icons.Filled.Settings, Color(0xFF546E7A), R.string.settings) { onNavigate(Routes.SETTINGS) }
            }
        }
    ) {
        Scaffold(
            containerColor = c.background,
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        if (searching) {
                            TextField(
                                value = text, onValueChange = { text = it }, singleLine = true,
                                placeholder = { Text(stringResource(R.string.search)) },
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(onSearch = { vm.search(text) }),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                    focusedTextColor = c.onPrimary, unfocusedTextColor = c.onPrimary,
                                    cursorColor = c.onPrimary,
                                    focusedPlaceholderColor = c.onPrimary.copy(alpha = 0.7f),
                                    unfocusedPlaceholderColor = c.onPrimary.copy(alpha = 0.7f)
                                )
                            )
                        } else {
                            Text(state.searchQuery ?: stringResource(state.category.title))
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Filled.Menu, null) }
                    },
                    actions = {
                        IconButton(onClick = {
                            if (searching) { searching = false; text = ""; if (state.searchQuery != null) vm.search("") }
                            else searching = true
                        }) { Icon(if (searching) Icons.Filled.Close else Icons.Filled.Search, null) }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = c.primary, titleContentColor = c.onPrimary,
                        navigationIconContentColor = c.onPrimary, actionIconContentColor = c.onPrimary
                    )
                )
            },
            bottomBar = { Column { ActiveTimersStrip { onNavigate(Routes.TIMERS) }; BannerAd() } }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when {
                    state.loading -> LoadingBox()
                    state.error -> MessageBox(stringResource(R.string.error_load), stringResource(R.string.retry)) { vm.retry() }
                    state.recipes.isEmpty() -> MessageBox(stringResource(R.string.no_results))
                    else -> RecipeGrid(
                        recipes = state.recipes, favoriteIds = favIds,
                        onRecipe = onRecipe, onFavorite = vm::toggleFavorite,
                        state = gridState, modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

@Composable
private fun DrawerLink(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, label: Int, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = { Text(stringResource(label)) },
        icon = { Icon(icon, null, tint = tint) },
        selected = false, onClick = onClick,
        modifier = Modifier.padding(horizontal = 12.dp)
    )
}
