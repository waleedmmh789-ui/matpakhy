package com.example.wasfati.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.wasfati.data.settings.ThemeMode

val Orange = Color(0xFFFF6D00)
val SuccessGreen = Color(0xFF2E7D32)   // زر + في قائمة التسوق

private val LightColors = lightColorScheme(
    primary = Orange, onPrimary = Color.White,
    background = Color(0xFFFFFFFF), onBackground = Color(0xFF1C1B1F),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF1C1B1F),
    surfaceVariant = Color(0xFFF5F5F5), onSurfaceVariant = Color(0xFF49454F)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFF8A3D), onPrimary = Color(0xFF1A0B00),
    background = Color(0xFF121212), onBackground = Color(0xFFEDEDED),
    surface = Color(0xFF1A1A1A), onSurface = Color(0xFFEDEDED),
    surfaceVariant = Color(0xFF262626), onSurfaceVariant = Color(0xFFCAC4D0)
)

@Composable
fun WasfatiTheme(themeMode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
