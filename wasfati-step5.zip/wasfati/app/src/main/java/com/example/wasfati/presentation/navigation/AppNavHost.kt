package com.example.wasfati.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.wasfati.presentation.details.DetailsScreen
import com.example.wasfati.presentation.favorites.FavoritesScreen
import com.example.wasfati.presentation.finder.FinderScreen
import com.example.wasfati.presentation.home.HomeScreen
import com.example.wasfati.presentation.onboarding.OnboardingScreen
import com.example.wasfati.presentation.settings.SettingsScreen
import com.example.wasfati.presentation.shopping.ShoppingScreen
import com.example.wasfati.presentation.timer.TimersScreen

object Routes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val DETAILS = "details/{id}"
    const val FINDER = "finder"
    const val FAVORITES = "favorites"
    const val SHOPPING = "shopping"
    const val SETTINGS = "settings"
    const val TIMERS = "timers"
    fun details(id: Int) = "details/$id"
}

@Composable
fun AppNavHost(start: String, openTimers: Boolean = false, onTimersOpened: () -> Unit = {}) {
    val nav = rememberNavController()
    val back: () -> Unit = { nav.popBackStack() }
    val openRecipe: (Int) -> Unit = { nav.navigate(Routes.details(it)) }
    val openTimersScreen: () -> Unit = { nav.navigate(Routes.TIMERS) { launchSingleTop = true } }

    // الضغط على إشعار المؤقت يفتح شاشة المؤقتات مباشرة
    LaunchedEffect(openTimers) {
        if (openTimers) { openTimersScreen(); onTimersOpened() }
    }

    NavHost(nav, startDestination = start) {
        composable(Routes.ONBOARDING) {
            OnboardingScreen(onFinish = {
                nav.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
            })
        }
        composable(Routes.HOME) { HomeScreen(onRecipe = openRecipe, onNavigate = { nav.navigate(it) }) }
        composable(Routes.DETAILS, arguments = listOf(navArgument("id") { type = NavType.IntType })) {
            DetailsScreen(onBack = back, onOpenTimers = openTimersScreen)
        }
        composable(Routes.FINDER) { FinderScreen(onBack = back, onRecipe = openRecipe) }
        composable(Routes.FAVORITES) { FavoritesScreen(onBack = back, onRecipe = openRecipe) }
        composable(Routes.SHOPPING) { ShoppingScreen(onBack = back) }
        composable(Routes.SETTINGS) { SettingsScreen(onBack = back) }
        composable(Routes.TIMERS) { TimersScreen(onBack = back) }
    }
}
