package com.example.wasfati.presentation.onboarding

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wasfati.R
import com.example.wasfati.data.settings.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OnboardingViewModel @Inject constructor(private val repo: SettingsRepository) : ViewModel() {
    fun finish(then: () -> Unit) = viewModelScope.launch { repo.setOnboardingDone(); then() }
}

private data class Slide(val icon: ImageVector, val color: Color, val title: Int, val desc: Int)

private val slides = listOf(
    Slide(Icons.Filled.Restaurant, Color(0xFFFF6D00), R.string.ob1_title, R.string.ob1_desc),
    Slide(Icons.Filled.ShoppingCart, Color(0xFF2E7D32), R.string.ob2_title, R.string.ob2_desc),
    Slide(Icons.Filled.CloudOff, Color(0xFF1E88E5), R.string.ob3_title, R.string.ob3_desc),
    Slide(Icons.Filled.Kitchen, Color(0xFF8E24AA), R.string.ob4_title, R.string.ob4_desc),
    Slide(Icons.Filled.RocketLaunch, Color(0xFFE53935), R.string.ob5_title, R.string.ob5_desc)
)

@Composable
fun OnboardingScreen(onFinish: () -> Unit, vm: OnboardingViewModel = hiltViewModel()) {
    val pager = rememberPagerState(pageCount = { slides.size })
    val scope = rememberCoroutineScope()
    val last = pager.currentPage == slides.lastIndex
    val finish = { vm.finish(onFinish); Unit }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(16.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.CenterEnd) {
            if (!last) TextButton(onClick = { finish() }) { Text(stringResource(R.string.skip)) }
        }
        HorizontalPager(pager, Modifier.weight(1f)) { i ->
            val s = slides[i]
            Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(180.dp).clip(CircleShape).background(s.color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) { Icon(s.icon, null, tint = s.color, modifier = Modifier.size(90.dp)) }
                Spacer(Modifier.height(32.dp))
                Text(stringResource(s.title), style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(Modifier.height(12.dp))
                Text(stringResource(s.desc), textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge)
            }
        }
        // مؤشر النقاط
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), Arrangement.Center) {
            repeat(slides.size) { i ->
                val c by animateColorAsState(
                    if (i == pager.currentPage) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f), label = "dot"
                )
                Box(Modifier.padding(4.dp).size(if (i == pager.currentPage) 12.dp else 8.dp).clip(CircleShape).background(c))
            }
        }
        Button(
            onClick = { if (last) finish() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(stringResource(if (last) R.string.start_now else R.string.next)) }
    }
}
