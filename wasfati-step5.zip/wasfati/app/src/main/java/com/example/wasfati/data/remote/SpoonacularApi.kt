package com.example.wasfati.data.remote

import com.example.wasfati.data.remote.dto.*
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface SpoonacularApi {

    /** بحث/تصنيف مع السعرات ووقت التحضير */
    @GET("recipes/complexSearch")
    suspend fun complexSearch(
        @Query("query") query: String? = null,
        @Query("type") type: String? = null,
        @Query("diet") diet: String? = null,
        @Query("maxCalories") maxCalories: Int? = null,
        @Query("addRecipeInformation") addInfo: Boolean = true,
        @Query("addRecipeNutrition") addNutrition: Boolean = true,
        @Query("number") number: Int = 20,
        @Query("offset") offset: Int = 0
    ): SearchResponseDto

    /** البحث بالمكونات المتوفرة (مفصولة بفواصل: apples,flour,sugar) */
    @GET("recipes/findByIngredients")
    suspend fun findByIngredients(
        @Query("ingredients") ingredients: String,
        @Query("number") number: Int = 20,
        @Query("ranking") ranking: Int = 1,
        @Query("ignorePantry") ignorePantry: Boolean = true
    ): List<IngredientMatchDto>

    /** تفاصيل الوصفة الكاملة */
    @GET("recipes/{id}/information")
    suspend fun getRecipeInformation(
        @Path("id") id: Int,
        @Query("includeNutrition") includeNutrition: Boolean = true
    ): RecipeDetailDto
}
