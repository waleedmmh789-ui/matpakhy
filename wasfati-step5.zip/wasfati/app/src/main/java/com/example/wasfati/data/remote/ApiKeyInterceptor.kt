package com.example.wasfati.data.remote

import okhttp3.Interceptor
import okhttp3.Response

/** يضيف apiKey تلقائياً لكل طلب */
class ApiKeyInterceptor(private val apiKey: String) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val req = chain.request()
        val url = req.url.newBuilder().addQueryParameter("apiKey", apiKey).build()
        return chain.proceed(req.newBuilder().url(url).build())
    }
}
