package com.example.wasfati.presentation.timer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wasfati.data.timer.TimerManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TimersViewModel @Inject constructor(private val manager: TimerManager) : ViewModel() {
    val timers = manager.timers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun start(label: String, minutes: Int) { viewModelScope.launch { manager.start(label, "", minutes * 60) } }
    fun addMinute(id: Int) { viewModelScope.launch { manager.addMinute(id) } }
    fun cancel(id: Int) { viewModelScope.launch { manager.cancel(id) } }
}
