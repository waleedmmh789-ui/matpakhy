package com.example.wasfati.presentation.finder

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wasfati.domain.model.Recipe
import com.example.wasfati.domain.repository.RecipeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class FinderState(
    val input: String = "",
    val ingredients: List<String> = emptyList(),
    val results: List<Recipe> = emptyList(),
    val loading: Boolean = false,
    val error: Boolean = false,
    val searched: Boolean = false
)

@HiltViewModel
class FinderViewModel @Inject constructor(private val repo: RecipeRepository) : ViewModel() {
    private val _state = MutableStateFlow(FinderState())
    val state = _state.asStateFlow()
    val favoriteIds = repo.observeFavoriteIds().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    fun onInput(t: String) = _state.update { it.copy(input = t) }

    fun add() = _state.update {
        val v = it.input.trim()
        if (v.isEmpty() || v in it.ingredients) it.copy(input = "") else it.copy(ingredients = it.ingredients + v, input = "")
    }

    fun remove(i: String) = _state.update { it.copy(ingredients = it.ingredients - i) }

    fun find() {
        val list = _state.value.ingredients
        if (list.isEmpty()) return
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = false) }
            repo.findByIngredients(list)
                .onSuccess { r -> _state.update { it.copy(loading = false, results = r, searched = true) } }
                .onFailure { _state.update { it.copy(loading = false, error = true) } }
        }
    }

    fun toggleFavorite(r: Recipe) { viewModelScope.launch { repo.toggleFavoriteById(r.id) } }
}
