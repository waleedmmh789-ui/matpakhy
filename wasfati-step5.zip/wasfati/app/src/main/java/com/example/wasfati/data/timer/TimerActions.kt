package com.example.wasfati.data.timer

object TimerActions {
    const val FIRE = "com.example.wasfati.TIMER_FIRE"
    const val STOP = "com.example.wasfati.TIMER_STOP"
    const val EXTRA_ID = "timer_id"
    const val EXTRA_OPEN_TIMERS = "open_timers"

    // أكواد PendingIntent مميّزة لكل مؤقت
    fun rc(id: Int, kind: Int) = id * 4 + kind
    const val K_FIRE = 0
    const val K_STOP = 1
    const val K_CONTENT = 2
    const val K_SHOW = 3
}
