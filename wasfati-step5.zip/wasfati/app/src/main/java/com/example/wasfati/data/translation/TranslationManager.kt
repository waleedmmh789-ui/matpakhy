package com.example.wasfati.data.translation

import com.example.wasfati.data.local.dao.TranslationDao
import com.example.wasfati.data.local.entity.TranslationEntity
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

/** ترجمة إنجليزي ← عربي على الجهاز. النتائج تُخزَّن في Room فلا تُترجم مرتين. */
@Singleton
class TranslationManager @Inject constructor(private val dao: TranslationDao) {

    private val translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.ARABIC)
                .build()
        )
    }
    @Volatile private var modelReady = false

    /** يحمّل حزمة اللغة (~30MB) مرة واحدة ثم تعمل الترجمة بدون إنترنت */
    suspend fun ensureModel(): Boolean {
        if (modelReady) return true
        return try {
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            modelReady = true; true
        } catch (e: Exception) { false }
    }

    suspend fun translate(text: String): String {
        if (text.isBlank()) return text
        dao.get(text)?.let { return it }
        if (!ensureModel()) return text            // فشل التحميل: نعرض الأصل
        return try {
            translator.translate(text).await().also { dao.put(TranslationEntity(text, it)) }
        } catch (e: Exception) { text }
    }

    private val arToEn by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ARABIC)
                .setTargetLanguage(TranslateLanguage.ENGLISH).build()
        )
    }

    /** عربي ← إنجليزي: للبحث وإدخال المكونات بالعربية */
    suspend fun toEnglish(text: String): String {
        val key = "ar2en|$text"
        dao.get(key)?.let { return it }
        return try {
            arToEn.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            arToEn.translate(text).await().also { dao.put(TranslationEntity(key, it)) }
        } catch (e: Exception) { text }
    }

    suspend fun translateAll(texts: List<String>): List<String> = coroutineScope {
        texts.map { async { translate(it) } }.awaitAll()
    }
}
