package com.example.wasfati.presentation.details

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.wasfati.R
import com.example.wasfati.domain.model.IngredientItem
import com.example.wasfati.domain.model.RecipeDetail
import com.example.wasfati.presentation.components.*
import com.example.wasfati.presentation.theme.SuccessGreen
import com.example.wasfati.presentation.timer.*
import kotlinx.coroutines.launch

@Composable
fun DetailsScreen(onBack: () -> Unit, onOpenTimers: () -> Unit = {}, vm: DetailsViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val isFav by vm.isFavorite.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val addedMsg = stringResource(R.string.added_to_list)
    val startedMsg = stringResource(R.string.timer_started)
    var metric by remember { mutableStateOf(false) }
    val c = MaterialTheme.colorScheme

    Scaffold(
        containerColor = c.background,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = { Column { ActiveTimersStrip(onOpenTimers); BannerAd() } }
    ) { pad ->
        when (val s = state) {
            DetailsState.Loading -> LoadingBox()
            DetailsState.Error -> MessageBox(stringResource(R.string.error_load), stringResource(R.string.retry)) { vm.load() }
            is DetailsState.Success -> {
                val d = s.detail
                val gate = rememberNotificationPermissionGate()
                val timers by vm.timers.collectAsStateWithLifecycle()
                LazyColumn(Modifier.padding(bottom = pad.calculateBottomPadding())) {
                    item { Header(d, isFav, onBack, vm::toggleFavorite) }
                    item {
                        Row(Modifier.fillMaxWidth().padding(16.dp), Arrangement.SpaceEvenly) {
                            ActionCircle(Icons.Filled.LocalFireDepartment, Color(0xFFE53935),
                                d.calories?.let { stringResource(R.string.kcal, it) } ?: "—")
                            ActionCircle(Icons.Filled.People, SuccessGreen,
                                d.servings?.let { stringResource(R.string.servings_fmt, it) } ?: "—")
                            ActionCircle(Icons.Filled.Share, Color(0xFF1E88E5), stringResource(R.string.share)) {
                                ctx.startActivity(Intent.createChooser(
                                    Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, shareText(d))
                                    }, null))
                            }
                            ActionCircle(Icons.Filled.SwapHoriz, Color(0xFF8E24AA), stringResource(R.string.convert_units)) { metric = !metric }
                            ActionCircle(Icons.Filled.Print, Color(0xFFFF6D00), stringResource(R.string.print_pdf)) { printRecipe(ctx, d, rtl) }
                        }
                    }
                    item { SectionTitle(stringResource(R.string.ingredients)) }
                    items(d.ingredients) { ing ->
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                                .clip(RoundedCornerShape(12.dp)).background(c.surfaceVariant).padding(start = 14.dp, end = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(ingredientText(ing, metric), Modifier.weight(1f).padding(vertical = 12.dp), color = c.onSurface)
                            IconButton(
                                onClick = { vm.addToShopping(ing); scope.launch { snackbar.showSnackbar(addedMsg) } },
                                modifier = Modifier.clip(CircleShape).background(SuccessGreen)
                            ) { Icon(Icons.Filled.Add, null, tint = Color.White) }
                        }
                    }
                    item { SectionTitle(stringResource(R.string.instructions)) }
                    itemsIndexed(d.steps) { i, step ->
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                            Box(Modifier.size(30.dp).clip(CircleShape).background(c.primary), contentAlignment = Alignment.Center) {
                                Text("${i + 1}", color = c.onPrimary, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(step, color = c.onBackground)
                                StepTimers(
                                    recipeId = d.id, stepIndex = i, step = step, timers = timers,
                                    onStart = { key, sec ->
                                        gate {
                                            vm.startStepTimer(key, step, sec)
                                            scope.launch { snackbar.showSnackbar(startedMsg) }
                                        }
                                    },
                                    onCancel = vm::cancelTimer
                                )
                            }
                        }
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}

@Composable
private fun Header(d: RecipeDetail, isFav: Boolean, onBack: () -> Unit, onFav: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(260.dp)) {
        AsyncImage(d.imageUrl, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        RoundIcon(Modifier.align(Alignment.TopStart).statusBarsPadding().padding(12.dp), onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.Black)
        }
        RoundIcon(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(12.dp), onFav) {
            Icon(if (isFav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null, tint = Color(0xFFE53935))
        }
        d.readyInMinutes?.let {
            Row(
                Modifier.align(Alignment.BottomStart).padding(12.dp).clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.primary).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Schedule, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(stringResource(R.string.minutes, it), color = MaterialTheme.colorScheme.onPrimary)
            }
        }
    }
    Text(d.title, Modifier.padding(16.dp, 16.dp, 16.dp, 0.dp), style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
}

@Composable
private fun RoundIcon(modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.92f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) { content() }
}

@Composable
private fun ActionCircle(icon: ImageVector, color: Color, label: String, onClick: (() -> Unit)? = null) {
    Column(Modifier.width(66.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(48.dp).clip(CircleShape).background(color.copy(alpha = 0.15f))
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = color) }
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface, maxLines = 2)
    }
}

@Composable
private fun SectionTitle(t: String) = Text(
    t, Modifier.padding(16.dp, 12.dp, 16.dp, 6.dp), style = MaterialTheme.typography.titleMedium,
    fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary
)

private fun fmt(a: Double) = if (a % 1.0 == 0.0) a.toInt().toString() else "%.1f".format(a)

private fun ingredientText(i: IngredientItem, metric: Boolean): String =
    if (metric && i.amount != null) "${fmt(i.amount)} ${i.unit.orEmpty()} ${i.name}".replace("  ", " ").trim()
    else i.original

private fun shareText(d: RecipeDetail) = buildString {
    appendLine(d.title); appendLine()
    d.ingredients.forEach { appendLine("• ${it.original}") }; appendLine()
    d.steps.forEachIndexed { i, s -> appendLine("${i + 1}. $s") }
}
