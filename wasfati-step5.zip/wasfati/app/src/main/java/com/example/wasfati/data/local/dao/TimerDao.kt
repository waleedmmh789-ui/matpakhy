package com.example.wasfati.data.local.dao

import androidx.room.*
import com.example.wasfati.data.local.entity.TimerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TimerDao {
    @Query("SELECT * FROM cooking_timers ORDER BY finished DESC, endAt ASC")
    fun observeAll(): Flow<List<TimerEntity>>

    @Query("SELECT * FROM cooking_timers")
    suspend fun getAll(): List<TimerEntity>

    @Query("SELECT * FROM cooking_timers WHERE id = :id")
    suspend fun get(id: Int): TimerEntity?

    @Insert
    suspend fun insert(t: TimerEntity): Long

    @Query("UPDATE cooking_timers SET endAt = :endAt, totalSeconds = :total, finished = 0 WHERE id = :id")
    suspend fun reschedule(id: Int, endAt: Long, total: Int)

    @Query("UPDATE cooking_timers SET finished = 1 WHERE id = :id")
    suspend fun markFinished(id: Int)

    @Query("DELETE FROM cooking_timers WHERE id = :id")
    suspend fun delete(id: Int)
}
