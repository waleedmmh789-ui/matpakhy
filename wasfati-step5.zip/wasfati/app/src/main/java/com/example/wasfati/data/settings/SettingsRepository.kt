package com.example.wasfati.data.settings

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "settings")

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val language: String = "ar",          // "ar" | "en"
    val onboardingDone: Boolean = false,
    val timerSound: Boolean = true,
    val timerVibration: Boolean = true
)

@Singleton
class SettingsRepository @Inject constructor(@ApplicationContext private val ctx: Context) {
    private object K {
        val THEME = stringPreferencesKey("theme")
        val LANG = stringPreferencesKey("lang")
        val ONBOARDING = booleanPreferencesKey("onboarding_done")
        val TIMER_SOUND = booleanPreferencesKey("timer_sound")
        val TIMER_VIB = booleanPreferencesKey("timer_vibration")
    }

    val settings: Flow<AppSettings> = ctx.dataStore.data.map { p ->
        AppSettings(
            themeMode = p[K.THEME]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM,
            language = p[K.LANG] ?: "ar",
            onboardingDone = p[K.ONBOARDING] ?: false,
            timerSound = p[K.TIMER_SOUND] ?: true,
            timerVibration = p[K.TIMER_VIB] ?: true
        )
    }

    suspend fun setThemeMode(m: ThemeMode) = ctx.dataStore.edit { it[K.THEME] = m.name }
    suspend fun setLanguage(tag: String) = ctx.dataStore.edit { it[K.LANG] = tag }
    suspend fun setOnboardingDone() = ctx.dataStore.edit { it[K.ONBOARDING] = true }
    suspend fun setTimerSound(v: Boolean) = ctx.dataStore.edit { it[K.TIMER_SOUND] = v }
    suspend fun setTimerVibration(v: Boolean) = ctx.dataStore.edit { it[K.TIMER_VIB] = v }
}
