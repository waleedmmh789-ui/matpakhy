package com.example.wasfati.domain.model

data class CookingTimer(
    val id: Int,
    val label: String,
    val recipeTitle: String,
    val stepKey: String,       // "recipeId:stepIndex:seconds" — يربط المؤقت بخطوة معيّنة
    val totalSeconds: Int,
    val endAt: Long,
    val finished: Boolean
)
