package com.example.wasfati.presentation.favorites

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.example.wasfati.R
import com.example.wasfati.domain.model.Recipe
import com.example.wasfati.domain.repository.RecipeRepository
import com.example.wasfati.presentation.components.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FavoritesViewModel @Inject constructor(private val repo: RecipeRepository) : ViewModel() {
    val favorites = repo.observeFavorites().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun remove(r: Recipe) { viewModelScope.launch { repo.toggleFavoriteById(r.id) } }
}

@Composable
fun FavoritesScreen(onBack: () -> Unit, onRecipe: (Int) -> Unit, vm: FavoritesViewModel = hiltViewModel()) {
    val list by vm.favorites.collectAsStateWithLifecycle()
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar(stringResource(R.string.favorites), onBack) },
        bottomBar = { BannerAd() }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (list.isEmpty()) MessageBox(stringResource(R.string.empty_favorites))
            else RecipeGrid(list, list.map { it.id }.toSet(), onRecipe, vm::remove, Modifier.fillMaxSize())
        }
    }
}
