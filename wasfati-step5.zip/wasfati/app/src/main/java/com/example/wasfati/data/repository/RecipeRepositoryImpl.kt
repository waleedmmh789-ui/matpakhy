package com.example.wasfati.data.repository

import com.example.wasfati.data.local.dao.*
import com.example.wasfati.data.local.entity.*
import com.example.wasfati.data.remote.SpoonacularApi
import com.example.wasfati.data.remote.dto.*
import com.example.wasfati.data.settings.SettingsRepository
import com.example.wasfati.data.translation.TranslationManager
import com.example.wasfati.domain.model.*
import com.example.wasfati.domain.repository.RecipeRepository
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RecipeRepositoryImpl @Inject constructor(
    private val api: SpoonacularApi,
    private val favoriteDao: FavoriteDao,
    private val shoppingDao: ShoppingDao,
    private val cacheDao: CacheDao,
    private val translator: TranslationManager,
    private val settings: SettingsRepository
) : RecipeRepository {

    private val gson = Gson()

    private companion object {
        const val LIST_TTL = 6L * 60 * 60 * 1000      // 6 ساعات
        const val DETAIL_TTL = 24L * 60 * 60 * 1000   // 24 ساعة
    }

    /** كاش: يستخدم المحفوظ إن كان حديثاً، وعند فشل الشبكة يعيد القديم بدل الخطأ */
    private suspend inline fun <reified T> cached(key: String, ttl: Long, crossinline fetch: suspend () -> T): T {
        val type = object : TypeToken<T>() {}.type
        val hit = cacheDao.get(key)
        if (hit != null && System.currentTimeMillis() - hit.cachedAt < ttl) return gson.fromJson(hit.json, type)
        return try {
            fetch().also { cacheDao.put(CachedResponseEntity(key, gson.toJson(it))) }
        } catch (e: IOException) {
            if (hit != null) gson.fromJson(hit.json, type) else throw e
        }
    }

    private suspend fun isArabic() = settings.settings.first().language == "ar"
    private suspend fun tr(text: String) = if (isArabic()) translator.translate(text) else text
    private suspend fun toEnglish(t: String) =
        if (t.any { it in '\u0600'..'\u06FF' }) translator.toEnglish(t) else t

    // ---------- Remote ----------
    override suspend fun search(query: String?, type: String?, diet: String?, offset: Int): Result<List<Recipe>> =
        runCatching {
            val q = query?.let { toEnglish(it) }
            val key = "search|$q|$type|$diet|$offset"
            val dto = cached<SearchResponseDto>(key, LIST_TTL) {
                api.complexSearch(query = q, type = type, diet = diet, offset = offset)
            }
            coroutineScope {
                dto.results.map { r ->
                    async {
                        Recipe(r.id, tr(r.title), r.image, r.nutrition?.calories, r.readyInMinutes, r.servings)
                    }
                }.awaitAll()
            }
        }

    override suspend fun findByIngredients(ingredients: List<String>): Result<List<Recipe>> = runCatching {
        val joined = ingredients.map { toEnglish(it.trim()) }.joinToString(",") { it.lowercase() }
        val list = cached<List<IngredientMatchDto>>("byIng|$joined", LIST_TTL) { api.findByIngredients(joined) }
        coroutineScope {
            list.map { r ->
                async { Recipe(r.id, tr(r.title), r.image, usedCount = r.usedIngredientCount, missedCount = r.missedIngredientCount) }
            }.awaitAll()
        }
    }

    override suspend fun getDetails(id: Int): Result<RecipeDetail> = runCatching {
        val d = cached<RecipeDetailDto>("detail|$id", DETAIL_TTL) { api.getRecipeInformation(id) }
        val steps = d.analyzedInstructions.flatMap { it.steps }.map { it.step }.ifEmpty {
            (d.instructions ?: "").replace(Regex("<[^>]*>"), " ")
                .split(".").map { it.trim() }.filter { it.isNotEmpty() }
        }
        coroutineScope {
            val title = async { tr(d.title) }
            val ings = d.extendedIngredients.map { e ->
                async {
                    IngredientItem(
                        name = tr(e.name ?: e.original.orEmpty()),
                        original = tr(e.original ?: e.name.orEmpty()),
                        amount = e.measures?.metric?.amount ?: e.amount,
                        unit = e.measures?.metric?.unitShort ?: e.unit
                    )
                }
            }
            val stepsTr = steps.map { async { tr(it) } }
            RecipeDetail(
                id = d.id, title = title.await(), imageUrl = d.image,
                readyInMinutes = d.readyInMinutes, servings = d.servings,
                calories = d.nutrition?.calories,
                ingredients = ings.awaitAll(), steps = stepsTr.awaitAll()
            )
        }
    }

    // ---------- Favorites (تعمل دون اتصال) ----------
    override fun observeFavorites(): Flow<List<Recipe>> = favoriteDao.observeAll().map { list ->
        list.map { Recipe(it.id, it.titleAr ?: it.title, it.imageUrl, it.calories, it.readyInMinutes, it.servings) }
    }

    override fun observeFavoriteIds(): Flow<Set<Int>> = favoriteDao.observeIds().map { it.toSet() }

    override suspend fun getFavoriteDetail(id: Int): RecipeDetail? = favoriteDao.getById(id)?.let { e ->
        RecipeDetail(
            id = e.id, title = e.titleAr ?: e.title, imageUrl = e.imageUrl,
            readyInMinutes = e.readyInMinutes, servings = e.servings, calories = e.calories,
            ingredients = gson.fromJson(e.ingredientsJson, object : TypeToken<List<IngredientItem>>() {}.type),
            steps = gson.fromJson(e.stepsJson, object : TypeToken<List<String>>() {}.type)
        )
    }

    override suspend fun toggleFavorite(detail: RecipeDetail) {
        if (favoriteDao.getById(detail.id) != null) {
            favoriteDao.delete(detail.id)
        } else {
            val ar = isArabic()
            favoriteDao.upsert(
                FavoriteRecipeEntity(
                    id = detail.id, title = detail.title, titleAr = if (ar) detail.title else null,
                    imageUrl = detail.imageUrl, calories = detail.calories,
                    readyInMinutes = detail.readyInMinutes, servings = detail.servings,
                    ingredientsJson = gson.toJson(detail.ingredients),
                    stepsJson = gson.toJson(detail.steps)
                )
            )
        }
    }

    override suspend fun toggleFavoriteById(id: Int) {
        if (favoriteDao.getById(id) != null) favoriteDao.delete(id)
        else getDetails(id).onSuccess { toggleFavorite(it) }
    }

    // ---------- Shopping ----------
    override fun observeShopping(): Flow<List<ShoppingItem>> = shoppingDao.observeAll().map { list ->
        list.map { ShoppingItem(it.id, it.recipeId, it.recipeTitle, it.name, it.isChecked) }
    }

    override suspend fun addToShopping(detail: RecipeDetail, ingredient: IngredientItem) {
        shoppingDao.insert(
            ShoppingItemEntity(
                recipeId = detail.id, recipeTitle = detail.title,
                name = ingredient.original, amount = ingredient.amount, unit = ingredient.unit
            )
        )
    }

    override suspend fun setShoppingChecked(id: Long, checked: Boolean) = shoppingDao.setChecked(id, checked)
    override suspend fun deleteShopping(id: Long) = shoppingDao.deleteById(id)
    override suspend fun clearCheckedShopping() = shoppingDao.clearChecked()
}
