package com.example.wasfati.domain.model

data class Recipe(
    val id: Int,
    val title: String,          // مترجم حسب لغة التطبيق
    val imageUrl: String?,
    val calories: Int? = null,
    val readyInMinutes: Int? = null,
    val servings: Int? = null,
    val usedCount: Int = 0,     // للبحث بالمكونات
    val missedCount: Int = 0
)

data class IngredientItem(
    val name: String,
    val original: String,       // النص الكامل مع الكمية
    val amount: Double?,
    val unit: String?
)

data class RecipeDetail(
    val id: Int,
    val title: String,
    val imageUrl: String?,
    val readyInMinutes: Int?,
    val servings: Int?,
    val calories: Int?,
    val ingredients: List<IngredientItem>,
    val steps: List<String>
)

data class ShoppingItem(
    val id: Long,
    val recipeId: Int,
    val recipeTitle: String,
    val name: String,
    val isChecked: Boolean
)
