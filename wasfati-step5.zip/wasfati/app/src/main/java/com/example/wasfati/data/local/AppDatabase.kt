package com.example.wasfati.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.wasfati.data.local.dao.*
import com.example.wasfati.data.local.entity.*

@Database(
    entities = [
        FavoriteRecipeEntity::class,
        ShoppingItemEntity::class,
        CachedResponseEntity::class,
        TranslationEntity::class,
        TimerEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun shoppingDao(): ShoppingDao
    abstract fun cacheDao(): CacheDao
    abstract fun translationDao(): TranslationDao
    abstract fun timerDao(): TimerDao
}
