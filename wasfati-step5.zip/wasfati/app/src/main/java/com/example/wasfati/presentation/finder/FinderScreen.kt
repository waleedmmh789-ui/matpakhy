package com.example.wasfati.presentation.finder

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.wasfati.R
import com.example.wasfati.presentation.components.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FinderScreen(onBack: () -> Unit, onRecipe: (Int) -> Unit, vm: FinderViewModel = hiltViewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    val favIds by vm.favoriteIds.collectAsStateWithLifecycle()
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar(stringResource(R.string.recipe_finder), onBack) },
        bottomBar = { BannerAd() }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = s.input, onValueChange = vm::onInput, singleLine = true,
                    placeholder = { Text(stringResource(R.string.finder_hint)) },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { vm.add() }),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                FilledIconButton(onClick = vm::add) { Icon(Icons.Filled.Add, stringResource(R.string.add)) }
            }
            FlowRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                s.ingredients.forEach { ing ->
                    InputChip(
                        selected = false, onClick = { vm.remove(ing) }, label = { Text(ing) },
                        trailingIcon = { Icon(Icons.Filled.Close, null, Modifier.size(16.dp)) }
                    )
                }
            }
            Button(
                onClick = vm::find, enabled = s.ingredients.isNotEmpty() && !s.loading,
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) { Text(stringResource(R.string.find_recipes)) }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    s.loading -> LoadingBox()
                    s.error -> MessageBox(stringResource(R.string.error_load), stringResource(R.string.retry)) { vm.find() }
                    s.searched && s.results.isEmpty() -> MessageBox(stringResource(R.string.no_results))
                    else -> RecipeGrid(
                        recipes = s.results, favoriteIds = favIds, onRecipe = onRecipe,
                        onFavorite = vm::toggleFavorite, modifier = Modifier.fillMaxSize(),
                        extra = { null }
                    )
                }
            }
        }
    }
}
