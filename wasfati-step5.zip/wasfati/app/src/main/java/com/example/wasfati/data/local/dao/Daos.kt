package com.example.wasfati.data.local.dao

import androidx.room.*
import com.example.wasfati.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorite_recipes ORDER BY savedAt DESC")
    fun observeAll(): Flow<List<FavoriteRecipeEntity>>

    @Query("SELECT id FROM favorite_recipes")
    fun observeIds(): Flow<List<Int>>

    @Query("SELECT * FROM favorite_recipes WHERE id = :id")
    suspend fun getById(id: Int): FavoriteRecipeEntity?

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_recipes WHERE id = :id)")
    fun isFavorite(id: Int): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(recipe: FavoriteRecipeEntity)

    @Query("DELETE FROM favorite_recipes WHERE id = :id")
    suspend fun delete(id: Int)
}

@Dao
interface ShoppingDao {
    @Query("SELECT * FROM shopping_items ORDER BY isChecked ASC, addedAt DESC")
    fun observeAll(): Flow<List<ShoppingItemEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: ShoppingItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<ShoppingItemEntity>)

    @Query("UPDATE shopping_items SET isChecked = :checked WHERE id = :id")
    suspend fun setChecked(id: Long, checked: Boolean)

    @Query("DELETE FROM shopping_items WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM shopping_items WHERE isChecked = 1")
    suspend fun clearChecked()

    @Query("DELETE FROM shopping_items")
    suspend fun clearAll()
}

@Dao
interface CacheDao {
    @Query("SELECT * FROM api_cache WHERE cacheKey = :key")
    suspend fun get(key: String): CachedResponseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(entry: CachedResponseEntity)

    @Query("DELETE FROM api_cache WHERE cachedAt < :olderThan")
    suspend fun purge(olderThan: Long)
}

@Dao
interface TranslationDao {
    @Query("SELECT translated FROM translations WHERE sourceText = :text")
    suspend fun get(text: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(entry: TranslationEntity)
}
