package com.example.wasfati.presentation.shopping

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.example.wasfati.R
import com.example.wasfati.domain.repository.RecipeRepository
import com.example.wasfati.presentation.components.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ShoppingViewModel @Inject constructor(private val repo: RecipeRepository) : ViewModel() {
    val items = repo.observeShopping().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun check(id: Long, v: Boolean) { viewModelScope.launch { repo.setShoppingChecked(id, v) } }
    fun delete(id: Long) { viewModelScope.launch { repo.deleteShopping(id) } }
    fun clearChecked() { viewModelScope.launch { repo.clearCheckedShopping() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingScreen(onBack: () -> Unit, vm: ShoppingViewModel = hiltViewModel()) {
    val list by vm.items.collectAsStateWithLifecycle()
    val c = MaterialTheme.colorScheme
    Scaffold(
        containerColor = c.background,
        topBar = {
            AppTopBar(stringResource(R.string.shopping_list), onBack) {
                IconButton(onClick = vm::clearChecked) {
                    Icon(Icons.Filled.DeleteSweep, stringResource(R.string.clear_checked))
                }
            }
        },
        bottomBar = { BannerAd() }
    ) { pad ->
        if (list.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize()) { MessageBox(stringResource(R.string.empty_shopping)) }
        } else LazyColumn(
            Modifier.padding(pad), contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.id }) { item ->
                Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = c.surfaceVariant)) {
                    Row(Modifier.fillMaxWidth().padding(end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(item.isChecked, { vm.check(item.id, it) })
                        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                            Text(
                                item.name, color = c.onSurface,
                                textDecoration = if (item.isChecked) TextDecoration.LineThrough else null
                            )
                            Text(item.recipeTitle, style = MaterialTheme.typography.labelSmall, color = c.onSurfaceVariant)
                        }
                        IconButton({ vm.delete(item.id) }) { Icon(Icons.Filled.Delete, null, tint = c.onSurfaceVariant) }
                    }
                }
            }
        }
    }
}
