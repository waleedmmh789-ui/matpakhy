package com.example.wasfati

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.google.android.gms.ads.MobileAds
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class WasfatiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        MobileAds.initialize(this)
        // أول تشغيل: العربية افتراضياً (RTL تلقائي)
        if (AppCompatDelegate.getApplicationLocales().isEmpty) {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("ar"))
        }
    }
}
