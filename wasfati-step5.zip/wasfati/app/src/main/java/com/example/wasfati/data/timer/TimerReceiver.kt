package com.example.wasfati.data.timer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class TimerReceiver : BroadcastReceiver() {
    @Inject lateinit var manager: TimerManager

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)   // مطلوب لحقن Hilt
        val id = intent.getIntExtra(TimerActions.EXTRA_ID, -1)
        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                when (intent.action) {
                    TimerActions.FIRE -> if (id >= 0) manager.onFired(id)
                    TimerActions.STOP -> if (id >= 0) manager.cancel(id)
                    Intent.ACTION_BOOT_COMPLETED -> manager.rescheduleAll()
                }
            } finally { pending.finish() }
        }
    }
}
