package com.example.wasfati.domain.repository

import com.example.wasfati.domain.model.*
import kotlinx.coroutines.flow.Flow

interface RecipeRepository {
    suspend fun search(query: String? = null, type: String? = null, diet: String? = null, offset: Int = 0): Result<List<Recipe>>
    suspend fun findByIngredients(ingredients: List<String>): Result<List<Recipe>>
    suspend fun getDetails(id: Int): Result<RecipeDetail>

    fun observeFavorites(): Flow<List<Recipe>>
    fun observeFavoriteIds(): Flow<Set<Int>>
    suspend fun getFavoriteDetail(id: Int): RecipeDetail?
    suspend fun toggleFavorite(detail: RecipeDetail)
    /** يحذف إن كانت مفضلة، وإلا يجلب التفاصيل ويحفظها */
    suspend fun toggleFavoriteById(id: Int)

    fun observeShopping(): Flow<List<ShoppingItem>>
    suspend fun addToShopping(detail: RecipeDetail, ingredient: IngredientItem)
    suspend fun setShoppingChecked(id: Long, checked: Boolean)
    suspend fun deleteShopping(id: Long)
    suspend fun clearCheckedShopping()
}
