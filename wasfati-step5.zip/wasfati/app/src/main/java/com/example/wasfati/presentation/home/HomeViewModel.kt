package com.example.wasfati.presentation.home

import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wasfati.R
import com.example.wasfati.domain.model.Recipe
import com.example.wasfati.domain.repository.RecipeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class Category(@StringRes val title: Int, val type: String?, val query: String?) {
    HEALTHY(R.string.cat_healthy, null, "healthy"),
    BREAKFAST(R.string.cat_breakfast, "breakfast", null),
    MAIN(R.string.cat_main, "main course", null),
    SALAD(R.string.cat_salad, "salad", null),
    SOUP(R.string.cat_soup, "soup", null),
    SNACK(R.string.cat_snack, "snack", null),
    DESSERT(R.string.cat_dessert, "dessert", null)
}

data class HomeUiState(
    val category: Category = Category.HEALTHY,
    val searchQuery: String? = null,
    val recipes: List<Recipe> = emptyList(),
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val error: Boolean = false,
    val endReached: Boolean = false
)

@HiltViewModel
class HomeViewModel @Inject constructor(private val repo: RecipeRepository) : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state = _state.asStateFlow()
    val favoriteIds = repo.observeFavoriteIds()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    private var job: Job? = null
    private val pageSize = 20

    init { load(reset = true) }

    fun selectCategory(c: Category) { _state.update { it.copy(category = c, searchQuery = null) }; load(true) }
    fun search(q: String) { _state.update { it.copy(searchQuery = q.trim().ifBlank { null }) }; load(true) }
    fun retry() = load(true)
    fun loadMore() {
        val s = _state.value
        if (s.loading || s.loadingMore || s.endReached || s.recipes.isEmpty()) return
        load(false)
    }
    fun toggleFavorite(r: Recipe) { viewModelScope.launch { repo.toggleFavoriteById(r.id) } }

    private fun load(reset: Boolean) {
        job?.cancel()
        job = viewModelScope.launch {
            _state.update {
                it.copy(loading = reset, loadingMore = !reset, error = false,
                    recipes = if (reset) emptyList() else it.recipes,
                    endReached = if (reset) false else it.endReached)
            }
            val s = _state.value
            val searching = s.searchQuery != null
            repo.search(
                query = if (searching) s.searchQuery else s.category.query,
                type = if (searching) null else s.category.type,
                offset = if (reset) 0 else s.recipes.size
            ).onSuccess { list ->
                _state.update {
                    it.copy(loading = false, loadingMore = false,
                        recipes = (it.recipes + list).distinctBy { r -> r.id },
                        endReached = list.size < pageSize)
                }
            }.onFailure {
                _state.update { it.copy(loading = false, loadingMore = false, error = it.recipes.isEmpty()) }
            }
        }
    }
}
