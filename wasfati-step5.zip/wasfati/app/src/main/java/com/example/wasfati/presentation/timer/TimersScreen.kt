package com.example.wasfati.presentation.timer

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.wasfati.R
import com.example.wasfati.domain.model.CookingTimer
import com.example.wasfati.presentation.components.AppTopBar
import com.example.wasfati.presentation.components.BannerAd
import com.example.wasfati.presentation.components.MessageBox

@Composable
fun TimersScreen(onBack: () -> Unit, vm: TimersViewModel = hiltViewModel()) {
    val timers by vm.timers.collectAsStateWithLifecycle()
    val now by rememberNow()
    var showNew by remember { mutableStateOf(false) }
    val gate = rememberNotificationPermissionGate()
    val ctx = LocalContext.current

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar(stringResource(R.string.timers), onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showNew = true },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text(stringResource(R.string.timer_new)) }
            )
        },
        bottomBar = { BannerAd() }
    ) { pad ->
        if (timers.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize()) { MessageBox(stringResource(R.string.timer_empty)) }
        } else LazyColumn(
            Modifier.padding(pad), contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(timers, key = { it.id }) { t -> TimerCard(t, now, { vm.addMinute(t.id) }, { vm.cancel(t.id) }) }
        }
    }

    if (showNew) NewTimerDialog(onDismiss = { showNew = false }) { minutes ->
        showNew = false
        gate { vm.start(ctx.getString(R.string.timer_manual_label, minutes), minutes) }
    }
}

@Composable
private fun TimerCard(t: CookingTimer, now: Long, onAddMinute: () -> Unit, onStop: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val left = ((t.endAt - now) / 1000).toInt().coerceAtLeast(0)
    val done = t.finished || left <= 0
    val accent = if (done) Color(0xFFE53935) else c.primary
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = c.surfaceVariant)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { if (done) 1f else left / t.totalSeconds.toFloat() },
                    modifier = Modifier.size(64.dp), color = accent, trackColor = accent.copy(alpha = 0.18f), strokeWidth = 5.dp
                )
                Icon(Icons.Filled.Timer, null, tint = accent)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (done) stringResource(R.string.timer_finished) else formatClock(left),
                    style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = accent
                )
                Text(t.label, maxLines = 2, color = c.onSurface, style = MaterialTheme.typography.bodyMedium)
                if (t.recipeTitle.isNotBlank())
                    Text(t.recipeTitle, maxLines = 1, color = c.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                TextButton(onClick = onAddMinute) { Text(stringResource(R.string.timer_add_minute)) }
                TextButton(onClick = onStop) {
                    Text(stringResource(if (done) R.string.timer_stop else R.string.timer_cancel), color = Color(0xFFE53935))
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun NewTimerDialog(onDismiss: () -> Unit, onStart: (Int) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.timer_new)) },
        text = {
            Column {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5, 10, 15, 20, 30, 45, 60).forEach { m ->
                        FilterChip(
                            selected = text == m.toString(), onClick = { text = m.toString() },
                            label = { Text(stringResource(R.string.minutes, m)) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = text, onValueChange = { text = it.filter(Char::isDigit).take(4) },
                    label = { Text(stringResource(R.string.timer_minutes_hint)) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
        },
        confirmButton = {
            TextButton(enabled = (text.toIntOrNull() ?: 0) > 0, onClick = { onStart(text.toInt()) }) {
                Text(stringResource(R.string.timer_start))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.timer_cancel)) } }
    )
}
