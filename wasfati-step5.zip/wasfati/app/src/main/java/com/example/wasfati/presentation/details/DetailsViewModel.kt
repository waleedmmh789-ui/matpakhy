package com.example.wasfati.presentation.details

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wasfati.data.timer.TimerManager
import com.example.wasfati.domain.model.IngredientItem
import com.example.wasfati.domain.model.RecipeDetail
import com.example.wasfati.domain.repository.RecipeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface DetailsState {
    data object Loading : DetailsState
    data object Error : DetailsState
    data class Success(val detail: RecipeDetail) : DetailsState
}

@HiltViewModel
class DetailsViewModel @Inject constructor(
    savedState: SavedStateHandle,
    private val repo: RecipeRepository,
    private val timerManager: TimerManager
) : ViewModel() {

    private val id: Int = checkNotNull(savedState["id"])
    private val _state = MutableStateFlow<DetailsState>(DetailsState.Loading)
    val state = _state.asStateFlow()
    val isFavorite = repo.observeFavoriteIds().map { id in it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val timers = timerManager.timers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init { load() }

    fun load() = viewModelScope.launch {
        _state.value = DetailsState.Loading
        repo.getFavoriteDetail(id)?.let { _state.value = DetailsState.Success(it); return@launch }
        repo.getDetails(id)
            .onSuccess { _state.value = DetailsState.Success(it) }
            .onFailure { _state.value = DetailsState.Error }
    }

    fun toggleFavorite() {
        val d = (_state.value as? DetailsState.Success)?.detail ?: return
        viewModelScope.launch { repo.toggleFavorite(d) }
    }

    fun addToShopping(i: IngredientItem) {
        val d = (_state.value as? DetailsState.Success)?.detail ?: return
        viewModelScope.launch { repo.addToShopping(d, i) }
    }

    fun startStepTimer(key: String, stepText: String, seconds: Int) {
        val title = (_state.value as? DetailsState.Success)?.detail?.title.orEmpty()
        viewModelScope.launch { timerManager.start(stepText.take(80), title, seconds, key) }
    }

    fun cancelTimer(timerId: Int) { viewModelScope.launch { timerManager.cancel(timerId) } }
}
