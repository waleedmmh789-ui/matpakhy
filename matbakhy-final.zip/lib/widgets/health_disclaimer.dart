import 'package:flutter/material.dart';
import '../localization/app_localizations.dart';

/// نص التنبيه الصحي لحاسبة السعرات (يُستخدم في الحاسبة وزر الصفحة الرئيسية).
const String kCalcDisclaimerTitle = 'تنبيه هام';
const String kCalcDisclaimerTitleEn = 'Important Notice';
const String kCalcDisclaimerTextEn =
    'Nutrition values and calories in the app are estimates for general information only, '
    'and may vary depending on ingredients, preparation method and quantities. '
    'They are not medical or dietary advice and do not replace consulting a doctor or a nutritionist, '
    'especially for people with diabetes, heart conditions, pregnant women and those on therapeutic diets.';
const String kCalcDisclaimerText =
    'القيم الغذائية والسعرات الحرارية في التطبيق تقديرية وللمعلومات العامة فقط، '
    'وقد تختلف حسب المكونات وطريقة التحضير والكميات. '
    'لا تُعدّ نصيحة طبية أو غذائية، ولا تغني عن استشارة الطبيب أو أخصائي التغذية، '
    'خصوصاً لمرضى السكري والقلب والحوامل وأصحاب الحميات العلاجية.';

/// بطاقة تنبيه ظاهرة دائماً أعلى شاشة الحاسبة.
class HealthDisclaimerCard extends StatelessWidget {
  const HealthDisclaimerCard({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF4A3B12) : const Color(0xFFFFF3CD),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFB300)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.warning_amber_rounded, color: Color(0xFFFFB300)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              isEnLocale(context) ? kCalcDisclaimerTextEn : kCalcDisclaimerText,
              style: TextStyle(
                fontSize: 13,
                height: 1.6,
                color: isDark ? Colors.white : Colors.black87,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// نافذة التنبيه (تُفتح من زر أعلى الصفحة الرئيسية).
Future<void> showHealthDisclaimer(BuildContext context) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      icon: const Icon(Icons.warning_amber_rounded, color: Color(0xFFFFB300), size: 36),
      title: Text(isEnLocale(context) ? kCalcDisclaimerTitleEn : kCalcDisclaimerTitle),
      content: Text(isEnLocale(context) ? kCalcDisclaimerTextEn : kCalcDisclaimerText,
          style: const TextStyle(height: 1.7)),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(isEnLocale(context) ? 'Got it' : 'فهمت')),
      ],
    ),
  );
}
