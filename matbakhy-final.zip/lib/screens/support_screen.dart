import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../localization/app_localizations.dart';
import '../widgets/matbakhy_logo.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/responsive_body.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  static const supportEmail = 'waleedmmh789@gmail.com';

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final en = isEnLocale(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.translate('support'))),
      bottomNavigationBar: const SafeArea(top: false, child: BannerAdWidget()),
      body: ResponsiveBody(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Center(child: MatbakhyLogo(size: 90)),
            const SizedBox(height: 12),
            Center(
              child: Text(t.translate('app_label'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 20),
            Text(
              en
                  ? 'For any question, suggestion or problem with the app, contact us by email:'
                  : 'لأي استفسار أو اقتراح أو مشكلة في التطبيق، تواصل معنا على البريد الإلكتروني:',
              style: const TextStyle(fontSize: 15, height: 1.6),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.email, color: Colors.deepOrange),
                title: const SelectableText(supportEmail),
                subtitle: Text(en ? 'Tap to copy' : 'اضغط للنسخ'),
                trailing: const Icon(Icons.copy),
                onTap: () async {
                  await Clipboard.setData(const ClipboardData(text: supportEmail));
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content: Text(en ? 'Email copied' : 'تم نسخ البريد الإلكتروني'),
                          duration: const Duration(seconds: 1)),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
