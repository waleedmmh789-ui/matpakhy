import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../localization/app_localizations.dart';
import '../providers/premium_provider.dart';
import '../widgets/responsive_body.dart';
import 'privacy_policy_screen.dart';
import 'refund_policy_screen.dart';

class PremiumScreen extends StatefulWidget {
  const PremiumScreen({super.key});

  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {
  String _selected = kPremiumProductId; // السنوي افتراضياً (الأوفر)

  static const _manageUrl = 'https://play.google.com/store/account/subscriptions?package=com.nader.matbakhy';

  Future<void> _confirmCancel(bool en) async {
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(en ? 'Cancel subscription' : 'إلغاء الاشتراك'),
        content: Text(
          en
              ? 'Cancelling stops future billing only and does not automatically refund the current period. You can keep using the benefits until the end of the paid period or the free trial.'
              : 'إلغاء الاشتراك يوقف الفوترة المستقبلية فقط ولا يردّ تلقائيًا قيمة الفترة الحالية، ويبقى بإمكانك استخدام المزايا حتى نهاية المدة المدفوعة أو الفترة التجريبية المجانية.',
          style: const TextStyle(height: 1.6),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(en ? 'Back' : 'رجوع')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(en ? 'Continue to Google Play' : 'متابعة إلى Google Play'),
          ),
        ],
      ),
    );
    if (go != true) return;
    try {
      await launchUrl(Uri.parse(_manageUrl), mode: LaunchMode.externalApplication);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(en
            ? 'Open Google Play > Payments & subscriptions > Subscriptions to cancel.'
            : 'افتح Google Play ← المدفوعات والاشتراكات ← الاشتراكات لإلغاء الاشتراك.'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final premium = context.watch<PremiumProvider>();
    final canBuy = premium.storeAvailable &&
        !premium.busy &&
        premium.productFor(_selected) != null;
    final saving = premium.yearlySavingPercent;
    final en = isEnLocale(context);
    String price(String s) => en ? s.replaceAll('سنة', 'year').replaceAll('شهر', 'month').replaceAll('أسبوع', 'week') : s;
    String? msg(String? m) {
      if (m == null || !en) return m;
      const map = {
        'تعذر إتمام الشراء. حاول مرة أخرى.': 'Could not complete the purchase. Please try again.',
        'تعذر بدء عملية الشراء.': 'Could not start the purchase.',
        'تعذر استعادة المشتريات.': 'Could not restore purchases.',
        'لم نجد اشتراكاً فعّالاً على هذا الحساب.': 'We could not find an active subscription on this account.',
      };
      return map[m] ?? m;
    }

    return Scaffold(
      appBar: AppBar(title: Text(en ? 'Premium Subscription' : 'الاشتراك المميز')),
      body: ResponsiveBody(
        maxWidth: 560,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 8),
            const Center(child: Text('👑', style: TextStyle(fontSize: 64))),
            const SizedBox(height: 8),
            Center(
              child: Text(en ? 'Upgrade to Premium' : 'ترقية للنسخة الممتازة',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.deepOrange)),
            ),
            const SizedBox(height: 24),
            _Feature(icon: Icons.block, text: en ? 'Browse with no ads at all' : 'تصفح بدون إعلانات نهائياً'),
            _Feature(icon: Icons.calculate, text: en ? 'Unlimited calorie calculator' : 'حاسبة السعرات بدون قيود'),
            _Feature(icon: Icons.photo_camera, text: en ? 'Change recipe photos freely, no ads' : 'تغيير صور الوصفات بحرية وبدون إعلانات'),
            _Feature(icon: Icons.favorite, text: en ? 'Support the app and its development' : 'دعم استمرار التطبيق وتطويره'),
            const SizedBox(height: 24),
            if (premium.isPremium) ...[
              Card(
                color: Colors.green.withOpacity(0.12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      const Icon(Icons.verified, color: Colors.green),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(en ? 'You are a Premium subscriber. Thank you for your support! ✨' : 'أنت مشترك في النسخة المميزة. شكراً لدعمك! ✨',
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                icon: const Icon(Icons.cancel_outlined),
                label: Text(en ? 'Cancel subscription' : 'إلغاء الاشتراك'),
                style: OutlinedButton.styleFrom(foregroundColor: Colors.red, padding: const EdgeInsets.symmetric(vertical: 14)),
                onPressed: () => _confirmCancel(en),
              ),
            ]
            else ...[
              _PlanCard(
                title: en ? 'Yearly plan' : 'اشتراك سنوي',
                price: price(premium.yearlyPriceLabel),
                badge: saving != null ? (en ? 'Save $saving%' : 'وفّر $saving%') : (en ? 'Best value' : 'الأوفر'),
                selected: _selected == kPremiumProductId,
                onTap: () => setState(() => _selected = kPremiumProductId),
              ),
              const SizedBox(height: 10),
              _PlanCard(
                title: en ? 'Monthly plan' : 'اشتراك شهري',
                price: price(premium.monthlyPriceLabel),
                selected: _selected == kMonthlyProductId,
                onTap: () => setState(() => _selected = kMonthlyProductId),
              ),
              const SizedBox(height: 10),
              _PlanCard(
                title: en ? 'Weekly plan' : 'اشتراك أسبوعي',
                price: price(premium.weeklyPriceLabel),
                selected: _selected == kWeeklyProductId,
                onTap: () => setState(() => _selected = kWeeklyProductId),
              ),
              const SizedBox(height: 14),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: Colors.deepOrange,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                onPressed: canBuy ? () => premium.buy(_selected) : null,
                child: premium.busy
                    ? const SizedBox(
                        height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(en ? 'Subscribe now (remove ads)' : 'اشترك الآن (إزالة الإعلانات)',
                        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              ),
              if (!premium.storeAvailable || !premium.hasProducts)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(en ? 'Google Play is currently unavailable or the products are not set up yet.' : 'متجر جوجل بلاي غير متاح حالياً أو المنتجات غير مُعرَّفة بعد.',
                      textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                ),
            ],
            const SizedBox(height: 8),
            TextButton(
              onPressed: (premium.busy || !premium.storeAvailable) ? null : premium.restore,
              child: Text(en ? 'Restore purchases' : 'استعادة المشتريات'),
            ),
            if (premium.message != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(msg(premium.message)!,
                    textAlign: TextAlign.center, style: const TextStyle(color: Colors.red)),
              ),
            const SizedBox(height: 16),
            Text(
              en
                  ? 'The subscription renews automatically (weekly, monthly or yearly depending on the plan you choose) unless you cancel it at least 24 hours before the renewal date. Your Google Play account is charged when the purchase is confirmed, and you can manage or cancel the subscription at any time from Google Play > Payments & subscriptions > Subscriptions.'
                  : 'الاشتراك يتجدد تلقائياً (كل أسبوع أو شهر أو سنة حسب الخطة التي تختارها) ما لم تلغِه قبل موعد التجديد '
                      'بـ 24 ساعة على الأقل. يُحاسَب الحساب على Google Play عند تأكيد الشراء، ويمكنك إدارة الاشتراك '
                      'أو إلغاؤه في أي وقت من Google Play ← المدفوعات والاشتراكات ← الاشتراكات.',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 11, color: Colors.grey, height: 1.6),
            ),
            const SizedBox(height: 8),
            Wrap(
              alignment: WrapAlignment.center,
              children: [
                TextButton(
                  onPressed: () => Navigator.push(
                      context, MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen())),
                  child: Text(en ? 'Privacy Policy' : 'سياسة الخصوصية'),
                ),
                TextButton(
                  onPressed: () => Navigator.push(
                      context, MaterialPageRoute(builder: (_) => const RefundPolicyScreen())),
                  child: Text(en ? 'Refund & Subscription Policy' : 'سياسة الاسترجاع والاشتراكات'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final String title;
  final String price;
  final String? badge;
  final bool selected;
  final VoidCallback onTap;
  const _PlanCard({
    required this.title,
    required this.price,
    required this.selected,
    required this.onTap,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? Colors.deepOrange : Colors.grey.shade400, width: selected ? 2 : 1),
          color: selected ? Colors.deepOrange.withOpacity(0.08) : null,
        ),
        child: Row(
          children: [
            Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off,
                color: selected ? Colors.deepOrange : Colors.grey),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      if (badge != null) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                              color: Colors.green, borderRadius: BorderRadius.circular(10)),
                          child: Text(badge!,
                              style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(price, style: const TextStyle(fontSize: 18)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Feature extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Feature({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, color: Colors.deepOrange),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }
}
