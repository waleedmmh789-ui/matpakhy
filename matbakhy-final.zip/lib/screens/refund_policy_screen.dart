import 'package:flutter/material.dart';
import '../localization/app_localizations.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/responsive_body.dart';

/// سياسة الاسترجاع والاشتراكات. الصياغة عامة وتحيل إلى سياسات Google Play لأنها هي من يعالج
/// المدفوعات والاستردادات؛ راجعها قانونياً قبل النشر وعدّلها لو لديك سياسة استرداد خاصة.
class RefundPolicyScreen extends StatelessWidget {
  const RefundPolicyScreen({super.key});

  static const _sections = <(String, String)>[
    ('الخطط المتاحة',
        'نوفر ثلاث خطط اشتراك لإزالة الإعلانات: أسبوعية وشهرية وسنوية. الأسعار الظاهرة في شاشة الاشتراك هي ما يحاسبك به Google Play بعملة بلدك، وقد تشمل الضرائب حسب منطقتك.'),
    ('الاشتراك والتجديد التلقائي',
        'تبدأ مدة الاشتراك عند تأكيد الشراء، ويتجدد تلقائياً في نهاية كل مدة (أسبوع أو شهر أو سنة حسب الخطة) بنفس السعر المعروض وقت الاشتراك ما لم يُعلَن عن تغيير السعر مسبقاً عبر Google Play. يُخصم المبلغ من حساب Google Play الخاص بك.'),
    ('فترة الـ 48 ساعة',
        'يمكنك طلب استرداد المبلغ خلال 48 ساعة من عملية الشراء (داخل التطبيق أو الاشتراك)، وذلك حسب السياسات المطبّقة في Google Play. تتم معالجة الطلب عبر Google Play وليس من داخل التطبيق: افتح سجل المشتريات في Google Play وقدّم طلب الاسترداد. وإن واجهت مشكلة في الاشتراك (مثل عدم تفعيل المزايا بعد الدفع) فراسلنا على البريد أدناه.'),
    ('الإلغاء قبل التجديد',
        'إلغاء الاشتراك يوقف الفوترة المستقبلية فقط، ولا يردّ تلقائياً قيمة الفترة الحالية. ويبقى بإمكانك استخدام المزايا حتى نهاية المدة المدفوعة أو الفترة التجريبية المجانية (إن وُجدت). للإلغاء: Google Play ← صورة حسابك ← المدفوعات والاشتراكات ← الاشتراكات ← مطبخي ← إلغاء الاشتراك، ويُنصح بالإلغاء قبل موعد التجديد بوقت كافٍ (24 ساعة على الأقل). حذف التطبيق من جهازك لا يلغي الاشتراك.'),
    ('استعادة المشتريات',
        'عند إعادة تثبيت التطبيق أو تغيير الجهاز، افتح شاشة الاشتراك واضغط «استعادة المشتريات» بنفس حساب Google Play الذي اشتركت به لتفعيل اشتراكك مجدداً دون دفع إضافي.'),
    ('ما الذي يتغيّر بعد الاشتراك',
        'يوقف الاشتراك الفعّال جميع الإعلانات (فتح التطبيق، البانر، البيني، المكافئة)، ويفتح حاسبة السعرات وتغيير صور الوصفات دون الحاجة لمشاهدة إعلانات.'),
    ('عند انتهاء الاشتراك',
        'إن انتهى اشتراكك أو أُلغي أو فشل تجديده، تعود الإعلانات ونظام الاستخدامات المرتبط بالإعلانات المكافئة للحاسبة وتغيير الصور. تبقى وصفاتك المفضلة وبياناتك المحفوظة على جهازك كما هي.'),
    ('التواصل',
        'لأي استفسار عن الاشتراكات: waleedmmh789@gmail.com'),
  ];

  static const _sectionsEn = <(String, String)>[
    ('Available Plans',
        'We offer three ad-free subscription plans: weekly, monthly and yearly. The prices shown on the subscription screen are what Google Play charges in your local currency and may include taxes depending on your region.'),
    ('Subscription & Auto-Renewal',
        'Your subscription starts when the purchase is confirmed and renews automatically at the end of each period (week, month or year depending on the plan) at the price shown when you subscribed, unless Google Play notifies you of a price change in advance. The amount is charged to your Google Play account.'),
    ('48-Hour Window',
        'You can request a refund within 48 hours of the purchase (in-app purchase or subscription), subject to the policies applied by Google Play. The request is processed by Google Play, not inside the app: open your purchase history in Google Play and submit a refund request. If you have a problem with your subscription (for example, benefits not activated after payment), email us at the address below.'),
    ('Cancelling Before Renewal',
        'Cancelling a subscription stops future billing only; it does not automatically refund the current period. You can keep using the benefits until the end of the paid period or the free trial (if any). To cancel: Google Play > your profile picture > Payments & subscriptions > Subscriptions > Matbakhy > Cancel subscription, and cancel well before the renewal date (at least 24 hours is recommended). Uninstalling the app does not cancel the subscription.'),
    ('Restoring Purchases',
        'After reinstalling the app or switching devices, open the subscription screen and tap "Restore purchases" using the same Google Play account you subscribed with to reactivate your subscription at no extra cost.'),
    ('What Changes When You Subscribe',
        'An active subscription stops all ads (app-open, banner, interstitial and rewarded) and unlocks the calorie calculator and recipe photo changes without watching ads.'),
    ('When a Subscription Ends',
        'If your subscription expires, is cancelled or fails to renew, ads return, along with the rewarded-ad requirement for the calculator and photo changes. Your favorites and the data stored on your device remain unchanged.'),
    ('Contact',
        'For any subscription inquiry, email us at: waleedmmh789@gmail.com'),
  ];

  @override
  Widget build(BuildContext context) {
    final en = isEnLocale(context);
    return Scaffold(
      bottomNavigationBar: const SafeArea(top: false, child: BannerAdWidget()),
      appBar: AppBar(title: Text(en ? 'Refund & Subscription Policy' : 'سياسة الاسترجاع والاشتراكات')),
      body: ResponsiveBody(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            for (final (title, body) in (en ? _sectionsEn : _sections)) ...[
              Text(title,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepOrange)),
              const SizedBox(height: 6),
              Text(body, style: const TextStyle(fontSize: 15, height: 1.7)),
              const SizedBox(height: 18),
            ],
            Text(en ? 'Last updated: November 26, 2026' : 'آخر تحديث: 26 نوفمبر 2026',
                style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
