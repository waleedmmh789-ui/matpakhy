import 'package:flutter/material.dart';
import '../localization/app_localizations.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/responsive_body.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  static const _sections = <(String, String)>[
    ('مقدمة',
        'تطبيق «مطبخي - وصفات وحاسبة سعرات» يحترم خصوصيتك. توضح هذه السياسة ما الذي يحدث لبياناتك عند استخدام التطبيق.'),
    ('البيانات التي نجمعها',
        'نحن لا نجمع بيانات شخصية بأنفسنا: لا يوجد تسجيل دخول ولا حسابات، ولا نرسل معلومات عنك إلى خوادمنا. وللتوضيح، تتعامل مع بعض البيانات أطراف ثالثة كما هو مبيّن في قسمي «الإعلانات» و«الاشتراك المميز» أدناه.'),
    ('البيانات المخزنة على جهازك فقط',
        'يحفظ التطبيق على جهازك فقط: الوصفات المفضلة، وقائمة المشتريات، وجدول الوجبات، وإعدادات المظهر، وحالة الاشتراك، وعدّادات الإعلانات ورصيد استخدامات الحاسبة، وحالة نافذة التقييم، والصور التي تختارها لوصفاتك (تُنسخ إلى مجلد التطبيق الخاص على جهازك ولا تُرفع إلى أي خادم)، ونسخ صور الوصفات المحمّلة مؤقتاً للعرض. هذه البيانات لا تغادر جهازك، وتُحذف بحذف التطبيق أو بمسح بياناته من إعدادات الجهاز.'),
    ('الصلاحيات',
        '• الإشعارات: لتنبيهك عند انتهاء مؤقت الطبخ.\n• الكاميرا والصور: لا تُستخدم إلا عندما تضغط على زر الكاميرا أو اختيار صورة لإضافة صورة خاصة بوصفة، والصورة تُحفظ داخل التطبيق على جهازك فقط.\n• الإنترنت: لعرض الإعلانات وإتمام الاشتراك عبر Google Play وتحميل صور الوصفات التوضيحية. باقي مزايا التطبيق تعمل بدون إنترنت، وتُعرض صور احتياطية مضمّنة عند تعذر التحميل.\n• معرّف الإعلانات: تطلبه Google AdMob لعرض الإعلانات.\n• لا يستخدم التطبيق الميكروفون ولا الموقع الجغرافي ولا جهات الاتصال.'),
    ('مؤقت الطبخ والصوت',
        'عند انتهاء مؤقت الطبخ يُشغَّل صوت تنبيه مضمّن داخل التطبيق وإشعار على جهازك. الصوت يُشغَّل محلياً فقط، ولا يتم تسجيل أي صوت ولا إرسال أي بيانات بسببه. يمكنك إيقاف الإشعارات من إعدادات الجهاز في أي وقت.'),
    ('الإعلانات',
        'يعرض التطبيق إعلانات عبر Google AdMob: إعلان فتح التطبيق، وإعلانات بينية (بعد عدد من الوصفات أو استخدامات المؤقت، وعند اختيار بعض التصنيفات)، وإعلانات مكافئة (للحصول على استخدامات إضافية لحاسبة السعرات ولتغيير صورة وصفة)، وبانر. قد تجمع Google ويستخدم شركاؤها معرّف الإعلانات في جهازك وبيانات عن الجهاز والاستخدام (مثل عنوان IP) لعرض الإعلانات وقياس أدائها ومنع الاحتيال. في المناطق التي يشترط فيها القانون ذلك قد يُطلب منك الموافقة على الإعلانات المخصصة. يمكنك إعادة ضبط معرّف الإعلانات أو إلغاء تخصيص الإعلانات من إعدادات جهازك (الإعدادات ← Google ← الإعلانات). لمعرفة كيف تستخدم Google البيانات: policies.google.com/technologies/partner-sites. المشتركون في النسخة المميزة لا يرون أي إعلانات.'),
    ('صور الوصفات الموضحة',
        'للوصفات التي ليس لها صورة مضمّنة يطلب التطبيق صورة توضيحية عامة من خدمة TheMealDB (themealdb.com) باستخدام كلمة وصفية عامة مثل «rice» أو «fish»، ثم يحفظ الصورة على جهازك لعدم إعادة تحميلها. لا يُرسل التطبيق أي معلومات شخصية في هذا الطلب، لكن الخدمة قد ترى عنوان IP الخاص بك كأي موقع إنترنت. تظهر صور بديلة مضمّنة إن تعذّر التحميل.'),
    ('الاشتراك المميز',
        'تتم عمليات الدفع والاشتراك بالكامل عبر Google Play، ولا نرى ولا نخزن بيانات بطاقتك. يحتفظ التطبيق على جهازك بحالة الاشتراك فقط (مشترك/غير مشترك). نوفر خطط اشتراك أسبوعية وشهرية وسنوية تتجدد تلقائياً، ويمكنك إلغاؤها في أي وقت من Google Play ← المدفوعات والاشتراكات. لمزيد من التفاصيل راجع «سياسة الاسترجاع والاشتراكات» من الإعدادات أو من شاشة الاشتراك.'),
    ('تنبيه حاسبة السعرات والمعلومات الغذائية',
        'القيم الغذائية والسعرات الحرارية في التطبيق تقديرية وللمعلومات العامة فقط، وقد تختلف حسب المكونات وطريقة التحضير والكميات. لا تُعدّ نصيحة طبية أو غذائية، ولا تغني عن استشارة الطبيب أو أخصائي التغذية، خصوصاً لمرضى السكري والقلب والحوامل وأصحاب الحميات العلاجية. يمكنك قراءة هذا التنبيه في أي وقت من الزر ⚠ أعلى الصفحة الرئيسية.'),
    ('مشاركة الوصفات',
        'عند ضغطك على «مشاركة» ينشئ التطبيق صورة للوصفة على جهازك فقط، ثم تفتح قائمة المشاركة في أندرويد لتختار أنت التطبيق والجهة. لا نرسل الصورة إلى أي خادم من جهتنا، ولا نعرف مع من شاركتها. إن اخترت صورتك الخاصة للوصفة فستظهر في الصورة المشاركة.'),
    ('تقييم التطبيق',
        'قد نعرض لك عند فتح التطبيق طلباً لتقييمه مرة كل 3 أيام تقريباً، ويتم التقييم عبر نافذة Google Play الرسمية. إذا اخترت التقييم لن يظهر الطلب مرة أخرى، ونحفظ ذلك على جهازك فقط. التقييم اختياري تماماً، ولا نقدم مقابلاً عليه.'),
    ('حذف بياناتك',
        'بما أن بياناتك محفوظة على جهازك فقط، يمكنك حذفها بحذف التطبيق أو من إعدادات الجهاز ← التطبيقات ← مطبخي ← التخزين ← مسح البيانات. لطلب أي استفسار يخص بياناتك راسلنا على البريد أدناه.'),
    ('الأطفال',
        'التطبيق لا يستهدف الأطفال دون 13 عاماً ولا يجمع بيانات منهم عن قصد.'),
    ('التغييرات على السياسة',
        'قد نحدّث هذه السياسة من وقت لآخر، وسيظهر آخر تحديث في أسفل هذه الصفحة.'),
    ('التواصل',
        'لأي استفسار عن الخصوصية راسلنا على: waleedmmh789@gmail.com'),
  ];

  static const _sectionsEn = <(String, String)>[
    ('Introduction',
        'The "Matbakhy - Recipes & Calorie Calculator" app respects your privacy. This policy explains what happens to your data when you use the app.'),
    ('Data We Collect',
        'We do not collect personal data ourselves: there is no sign-in and no accounts, and we do not send information about you to our servers. For clarity, some data is handled by third parties as described in the "Ads" and "Premium Subscription" sections below.'),
    ('Data Stored on Your Device Only',
        'The app stores on your device only: favorite recipes, the shopping list, the meal plan, appearance and language settings, subscription status, ad counters and calculator-use balance, the rating-prompt state, the photos you choose for your recipes (copied into the app\'s private folder on your device and never uploaded to any server), and temporary copies of recipe pictures downloaded for display. This data never leaves your device and is deleted when you uninstall the app or clear its data from the device settings.'),
    ('Permissions',
        '• Notifications: to alert you when the cooking timer ends.\n• Camera and photos: used only when you tap the camera button or choose a photo to add a custom picture to a recipe; the picture is stored inside the app on your device only.\n• Internet: to show ads, complete subscriptions via Google Play and download illustrative recipe pictures. The rest of the app works offline, and built-in placeholder pictures are shown when downloading fails.\n• Advertising ID: requested by Google AdMob to show ads.\n• The app does not use the microphone, location or contacts.'),
    ('Cooking Timer and Sound',
        'When the cooking timer ends, a built-in alert sound plays inside the app along with a notification on your device. The sound plays locally only; no audio is recorded and no data is sent because of it. You can turn off notifications from the device settings at any time.'),
    ('Ads',
        'The app shows ads via Google AdMob: an app-open ad, interstitial ads (after a number of recipes or timer uses, and when choosing some categories), rewarded ads (to get extra calorie-calculator uses and to change a recipe photo) and banners. Google and its partners may collect and use the advertising ID on your device and device and usage data (such as IP address) to show ads, measure their performance and prevent fraud. Where the law requires it, you may be asked to consent to personalized ads. You can reset your advertising ID or opt out of ad personalization from your device settings (Settings > Google > Ads). To learn how Google uses data: policies.google.com/technologies/partner-sites. Premium subscribers do not see any ads.'),
    ('Recipe Pictures',
        'For recipes without a built-in picture, the app requests a generic illustrative picture from TheMealDB (themealdb.com) using a general keyword such as "rice" or "fish", then saves it on your device so it is not downloaded again. No personal information is sent in this request, although the service may see your IP address like any website. Built-in placeholder pictures are shown if downloading fails.'),
    ('Premium Subscription',
        'Payments and subscriptions are handled entirely through Google Play, and we neither see nor store your card details. The app keeps only the subscription status on your device (subscribed / not subscribed). We offer weekly, monthly and yearly plans that renew automatically, and you can cancel at any time from Google Play > Payments & subscriptions. For more details see the "Refund & Subscription Policy" in Settings or on the subscription screen.'),
    ('Calorie Calculator & Nutrition Notice',
        'Nutrition values and calories in the app are estimates for general information only, and may vary depending on ingredients, preparation method and quantities. They are not medical or dietary advice and do not replace consulting a doctor or a nutritionist, especially for people with diabetes, heart conditions, pregnant women and those on therapeutic diets. You can read this notice at any time from the ⚠ button at the top of the home page.'),
    ('Sharing Recipes',
        'When you tap "Share", the app creates an image of the recipe on your device only, then opens the Android share sheet so you choose the app and the recipient. We do not send the image to any server of ours, and we do not know with whom you shared it. If you choose your own picture for the recipe, it will appear in the shared image.'),
    ('Rating the App',
        'When you open the app we may ask you to rate it, about once every 3 days, and the rating is done through the official Google Play dialog. If you choose to rate, the request will not appear again, and we store this on your device only. Rating is entirely optional and we offer nothing in return.'),
    ('Deleting Your Data',
        'Since your data is stored on your device only, you can delete it by uninstalling the app or from device settings > Apps > Matbakhy > Storage > Clear data. For any inquiry about your data, email us at the address below.'),
    ('Children',
        'The app does not target children under 13 and does not knowingly collect data from them.'),
    ('Changes to This Policy',
        'We may update this policy from time to time, and the latest update date will appear at the bottom of this page.'),
    ('Contact',
        'For any privacy inquiry, email us at: waleedmmh789@gmail.com'),
  ];

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final en = isEnLocale(context);
    return Scaffold(
      bottomNavigationBar: const SafeArea(top: false, child: BannerAdWidget()),
      appBar: AppBar(title: Text(t.translate('privacy_policy'))),
      body: ResponsiveBody(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            for (final (title, body) in (en ? _sectionsEn : _sections)) ...[
              Text(title,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepOrange)),
              const SizedBox(height: 6),
              Text(body, style: const TextStyle(fontSize: 15, height: 1.7)),
              const SizedBox(height: 18),
            ],
            Text(en ? 'Last updated: November 26, 2026' : 'آخر تحديث: 26 نوفمبر 2026',
                style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
