import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:provider/provider.dart';
import '../models/recipe.dart';
import '../providers/recipes_provider.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/responsive_body.dart';
import 'home_screen.dart' show isEnglish;
import 'recipe_screen.dart';

/// جدول رمضان: 30 يوم، لكل يوم (فطار + سحور + حلويات) من وصفات التطبيق.
class RamadanScreen extends StatefulWidget {
  const RamadanScreen({super.key});

  @override
  State<RamadanScreen> createState() => _RamadanScreenState();
}

class _RamadanScreenState extends State<RamadanScreen> {
  List<Map<String, dynamic>> _plan = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final raw = await rootBundle.loadString('assets/data/ramadan_plan.json');
      _plan = (jsonDecode(raw) as List)
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    } catch (_) {
      _plan = [];
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final en = isEnglish(context);
    final data = context.watch<RecipesProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text(en ? 'Ramadan Meal Plan' : 'جدول رمضان 🌙',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      bottomNavigationBar: const SafeArea(top: false, child: BannerAdWidget()),
      body: ResponsiveBody(
        child: _loading || data.loading
            ? const Center(child: CircularProgressIndicator())
            : _plan.isEmpty
                ? Center(child: Text(en ? 'Could not load the plan' : 'تعذر تحميل الجدول'))
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _plan.length,
                    itemBuilder: (context, i) => _DayCard(day: _plan[i], data: data, en: en),
                  ),
      ),
    );
  }
}

class _DayCard extends StatelessWidget {
  final Map<String, dynamic> day;
  final RecipesProvider data;
  final bool en;
  const _DayCard({required this.day, required this.data, required this.en});

  @override
  Widget build(BuildContext context) {
    final rows = <(String, String, String?)>[
      ('🌙', en ? 'Iftar' : 'الفطار', day['iftar'] as String?),
      ('🥣', en ? 'Suhoor' : 'السحور', day['suhoor'] as String?),
      ('🍮', en ? 'Dessert' : 'حلويات', day['dessert'] as String?),
    ];
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [Color(0xFFFF7043), Color(0xFFD84315)]),
            ),
            child: Text(
              en ? 'Day ${day['day']}' : 'اليوم ${day['day']}',
              style: const TextStyle(
                  color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
          for (final (icon, label, id) in rows) _row(context, icon, label, data.byId(id)),
        ],
      ),
    );
  }

  Widget _row(BuildContext context, String icon, String label, Recipe? r) {
    if (r == null) return const SizedBox.shrink();
    return ListTile(
      dense: true,
      leading: Text(icon, style: const TextStyle(fontSize: 22)),
      title: Text(r.title(en), maxLines: 2, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text('$label · ${r.flag} ${r.cuisine(en)}'),
      trailing: Icon(Directionality.of(context) == TextDirection.rtl
                  ? Icons.chevron_left
                  : Icons.chevron_right),
      onTap: () => Navigator.push(
          context, MaterialPageRoute(builder: (_) => RecipeScreen(recipe: r))),
    );
  }
}
