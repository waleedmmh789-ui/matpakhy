import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/responsive_body.dart';
import '../localization/app_localizations.dart';
import '../services/notification_service.dart';

class TimerScreen extends StatefulWidget {
  final int initialMinutes;
  final String stepText;
  const TimerScreen({super.key, required this.initialMinutes, required this.stepText});

  @override
  State<TimerScreen> createState() => _TimerScreenState();
}

class _TimerScreenState extends State<TimerScreen> {
  late int _total;
  late int _remaining;
  Timer? _timer;
  bool _running = false;
  bool _done = false;
  final AudioPlayer _player = AudioPlayer();

  @override
  void initState() {
    super.initState();
    _total = widget.initialMinutes * 60;
    _remaining = _total;
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  void _start() {
    _timer?.cancel();
    setState(() => _running = true);
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_remaining <= 1) {
        _finish();
      } else {
        setState(() => _remaining--);
      }
    });
  }

  void _pause() {
    _timer?.cancel();
    setState(() => _running = false);
  }

  void _add5() {
    setState(() {
      _remaining += 300;
      _total += 300;
      _done = false;
    });
    if (!_running) _start();
  }

  Future<void> _finish() async {
    _timer?.cancel();
    if (!mounted) return;
    final t = AppLocalizations.of(context);
    setState(() {
      _remaining = 0;
      _running = false;
      _done = true;
    });
    // والتطبيق مفتوح: نشغّل التنبيه بنفسنا على قناة صوت "المنبّه".
    // وفي الخلفية: صوت القناة المخصص في الإشعار هو الذي يعمل (بدون ازدواج).
    final foreground = NotificationService().isForeground;
    if (foreground) {
      try {
        await _player.setAudioContext(AudioContext(
          android: const AudioContextAndroid(
            stayAwake: true,
            contentType: AndroidContentType.sonification,
            usageType: AndroidUsageType.alarm,
            audioFocus: AndroidAudioFocus.gain,
          ),
        ));
        await _player.setVolume(1.0); // أعلى مستوى للملف؛ مستوى صوت الجهاز يظل بيد المستخدم
        await _player.setReleaseMode(ReleaseMode.loop);
        await _player.play(AssetSource('alarm.wav'));
      } catch (_) {}
    }
    await NotificationService().showNotification(
      title: t.translate('notification_title'),
      body: '${t.translate('notification_body')} ${widget.stepText}',
    );
    if (!mounted) return;
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: Text(t.translate('time_up')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(t.translate('time_up_message')),
            const SizedBox(height: 10),
            Text(
              isEnLocale(ctx)
                  ? 'If the sound is low, raise the alarm volume using the device volume buttons.'
                  : 'لو الصوت منخفض، ارفع صوت المنبّه من أزرار صوت الجهاز.',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(t.translate('ok')),
          ),
        ],
      ),
    );
    await _player.stop();
    await NotificationService().cancelAll();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _player.dispose();
    super.dispose();
  }

  String get _label {
    final m = (_remaining ~/ 60).toString().padLeft(2, '0');
    final s = (_remaining % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final progress = _total == 0 ? 0.0 : _remaining / _total;

    return Scaffold(
      bottomNavigationBar: const SafeArea(top: false, child: BannerAdWidget()),
      appBar: AppBar(title: Text(t.translate('timer_screen_title'))),
      body: ResponsiveBody(
        maxWidth: 560,
        child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(widget.stepText,
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, height: 1.5)),
            const SizedBox(height: 32),
            SizedBox(
              width: 220,
              height: 220,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 220,
                    height: 220,
                    child: CircularProgressIndicator(
                      value: progress,
                      strokeWidth: 10,
                      color: Colors.deepOrange,
                    ),
                  ),
                  Text(_label, style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text(_done
                ? t.translate('time_up')
                : _running
                    ? t.translate('counting')
                    : t.translate('stopped')),
            const SizedBox(height: 32),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              alignment: WrapAlignment.center,
              children: [
                if (!_done)
                  ElevatedButton.icon(
                    onPressed: _running ? _pause : _start,
                    icon: Icon(_running ? Icons.pause : Icons.play_arrow),
                    label: Text(t.translate(_running ? 'pause' : 'resume')),
                  ),
                ElevatedButton.icon(
                  onPressed: _add5,
                  icon: const Icon(Icons.add),
                  label: Text(t.translate('add_5_min')),
                ),
                OutlinedButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                  label: Text(t.translate('cancel_timer')),
                ),
              ],
            ),
          ],
        ),
        ),
      ),
    );
  }
}
