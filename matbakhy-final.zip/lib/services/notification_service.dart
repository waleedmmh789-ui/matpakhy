import 'dart:typed_data';
import 'package:flutter/widgets.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// إشعارات مؤقت الطبخ.
///
/// - قناة التنبيه (alarm) لها صوت مخصص (res/raw/timer_alarm.wav) و AudioAttributes
///   بنوع "alarm"، فيُشغَّل الصوت على مستوى صوت المنبّه في الجهاز.
/// - التطبيق لا يستطيع تجاوز مستوى صوت النظام ولا إجبار المستخدم على رفعه، ولا يحاول ذلك.
///   المستخدم يتحكم في الصوت من أزرار الجهاز وإعدادات القناة.
/// - قنوات الإشعارات في أندرويد لا تتغير بعد إنشائها، لذلك استخدمنا معرّفات جديدة (v2).
class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  static const String alarmChannelId = 'cooking_timer_alarm_v2';
  static const String quietChannelId = 'cooking_timer_quiet_v2';
  static const String _alarmSound = 'timer_alarm'; // res/raw/timer_alarm.wav

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  /// هل التطبيق ظاهر أمام المستخدم الآن؟
  bool get isForeground =>
      WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed;

  static Int64List get _vibration => Int64List.fromList(<int>[0, 600, 300, 600, 300, 900]);

  Future<void> init() async {
    try {
      const settings = InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
        iOS: DarwinInitializationSettings(),
      );
      await _plugin.initialize(settings);
      final android = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      await android?.requestNotificationsPermission();

      // قناة بصوت مخصص + AudioAttributes (usage = alarm)
      await android?.createNotificationChannel(AndroidNotificationChannel(
        alarmChannelId,
        'تنبيه مؤقت الطبخ',
        description: 'صوت تنبيه عند انتهاء مؤقت الطبخ',
        importance: Importance.max,
        playSound: true,
        sound: const RawResourceAndroidNotificationSound(_alarmSound),
        audioAttributesUsage: AudioAttributesUsage.alarm,
        enableVibration: true,
        vibrationPattern: _vibration,
      ));
      // قناة صامتة تُستخدم والتطبيق مفتوح (الصوت يشغّله التطبيق نفسه)
      await android?.createNotificationChannel(const AndroidNotificationChannel(
        quietChannelId,
        'مؤقت الطبخ (التطبيق مفتوح)',
        description: 'إشعار بدون صوت عندما يكون التطبيق مفتوحاً',
        importance: Importance.high,
        playSound: false,
        enableVibration: true,
      ));
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  Future<void> showNotification({required String title, required String body}) async {
    if (!_ready) return;
    final fg = isForeground;
    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        fg ? quietChannelId : alarmChannelId,
        fg ? 'مؤقت الطبخ (التطبيق مفتوح)' : 'تنبيه مؤقت الطبخ',
        channelDescription: 'إشعارات مؤقت الطبخ',
        importance: fg ? Importance.high : Importance.max,
        priority: Priority.high,
        category: AndroidNotificationCategory.alarm,
        visibility: NotificationVisibility.public,
        playSound: !fg,
        sound: fg ? null : const RawResourceAndroidNotificationSound(_alarmSound),
        audioAttributesUsage: AudioAttributesUsage.alarm,
        enableVibration: true,
        vibrationPattern: fg ? null : _vibration,
        // يكرر الصوت حتى يتفاعل المستخدم مع الإشعار (FLAG_INSISTENT) وينتهي تلقائياً بعد دقيقة
        additionalFlags: fg ? null : Int32List.fromList(<int>[4]),
        timeoutAfter: fg ? null : 60000,
      ),
      iOS: const DarwinNotificationDetails(presentAlert: true, presentSound: true),
    );
    await _plugin.show(DateTime.now().millisecondsSinceEpoch ~/ 1000, title, body, details);
  }

  /// يوقف أي إشعار/صوت متكرر (يُستدعى عند ضغط "حسناً").
  Future<void> cancelAll() async {
    try {
      await _plugin.cancelAll();
    } catch (_) {}
  }
}
