import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cooking_app/services/matbakhy_prefs.dart';
import 'package:cooking_app/models/recipe.dart';
import 'package:cooking_app/services/nutrition_calculator.dart';
import 'package:cooking_app/services/recipe_image_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('merged recipes load with unique ids', () async {
    final raw = await rootBundle.loadString('assets/data/recipes.json');
    final list = (jsonDecode(raw) as List)
        .map((e) => Recipe.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
    expect(list.length, greaterThan(380));
    expect(list.map((r) => r.id).toSet().length, list.length);
    expect(list.where((r) => r.id.startsWith('matbakhy_')).length, 57);
  });

  test('every recipe has a 1-2 word imageKeyword and a local fallback asset', () async {
    final raw = await rootBundle.loadString('assets/data/recipes.json');
    final list = (jsonDecode(raw) as List)
        .map((e) => Recipe.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
    for (final r in list) {
      final words = r.imageKeyword.trim().split(RegExp(r'\s+'));
      expect(r.imageKeyword.trim().isNotEmpty && words.length <= 2, isTrue, reason: r.id);
      expect(File(RecipeImageService.fallbackAsset(r)).existsSync(), isTrue, reason: r.id);
    }
  });

  test('MatbakhyPrefs defaults, counters and legacy subscription key', () async {
    SharedPreferences.setMockInitialValues({'isPremiumUser': true});
    final p = await MatbakhyPrefs.load();
    expect(p.isSubscribed, isTrue); // مفتاح النسخ القديمة
    expect(p.calculatorRemainingUses, 0);
    expect(p.hasRatedApp, isFalse);
    expect(p.hasShownCountryAd, isFalse);
    p.calculatorRemainingUses = -5;
    expect(p.calculatorRemainingUses, 0); // لا قيم سالبة
    p.recipeOpenCounter = 2;
    p.timerUseCounter = 4;
    expect((await MatbakhyPrefs.load()).recipeOpenCounter, 2);
    expect((await MatbakhyPrefs.load()).timerUseCounter, 4);
  });

  test('most recipes have sane per-serving nutrition estimates', () async {
    final raw = await rootBundle.loadString('assets/data/recipes.json');
    final list = (jsonDecode(raw) as List)
        .map((e) => Recipe.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
    final withN = list.where((r) => r.nutrition != null).toList();
    expect(withN.length / list.length, greaterThan(0.95));
    for (final r in withN) {
      expect(r.nutrition!.kcal, inInclusiveRange(5, 3000), reason: r.id);
      expect(r.nutrition!.coverage, inInclusiveRange(50, 100), reason: r.id);
    }
  });

  test('english falls back to arabic when missing', () {
    final r = Recipe.fromJson({
      'id': 'x', 'titleAr': 'كشري', 'titleEn': '',
      'ingredients': [{'ar': 'أرز', 'en': ''}],
      'stepsAr': ['تُترك 20 دقيقة'], 'stepsEn': [],
    });
    expect(r.title(true), 'كشري');
    expect(r.ingredient(0, true), 'أرز');
    expect(r.steps(true).first.minutes, 20);
  });

  test('detectMinutes', () {
    expect(RecipeStep.detectMinutes('لمدة 3-4 ساعات'), 240);
    expect(RecipeStep.detectMinutes('simmer 15 min'), 15);
    expect(RecipeStep.detectMinutes('يُغسل الأرز'), isNull);
  });

  test('nutrition calculator (grams only)', () async {
    final c = NutritionCalculator();
    await c.loadDatabase();
    final r = c.calculateNutrition('250 جرام لحمة');
    expect(r['ingredient_name'], 'لحمة');
    expect(r['weight_grams'], 250);
    expect(r['calories'], closeTo(537.5, 0.01));
    expect(c.calculateNutrition('٢٠٠ جرام أرز مطبوخ')['ingredient_name'], 'أرز مطبوخ');
    expect(() => c.calculateNutrition('2 كوب أرز'), throwsException);
    expect(() => c.calculateNutrition('250 جرام حاجة'), throwsException);
  });
}
