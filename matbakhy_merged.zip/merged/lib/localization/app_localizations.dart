import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;
  AppLocalizations(this.locale);

  static AppLocalizations of(BuildContext context) =>
      Localizations.of<AppLocalizations>(context, AppLocalizations)!;

  static const LocalizationsDelegate<AppLocalizations> delegate = _Delegate();

  static const Map<String, Map<String, String>> _values = {
    'ar': {
      'app_title': 'مطبخي',
      'search_hint': 'ابحث عن وصفة أو مكون...',
      'all': 'الكل',
      'no_results': 'لا توجد نتائج',
      'ingredients': 'المكونات',
      'steps': 'طريقة التحضير',
      'tips': 'نصيحة',
      'favorites': 'المفضلة',
      'no_favorites': 'لا توجد وصفات مفضلة بعد',
      'shopping_list': 'قائمة المشتريات',
      'shopping_empty': 'قائمة المشتريات فاضية',
      'add_item_hint': 'أضف عنصراً جديداً',
      'clear_checked': 'حذف المشطوب',
      'added_to_shopping': 'تمت الإضافة لقائمة المشتريات',
      'already_in_shopping': 'المكونات موجودة بالفعل في القائمة',
      'add_all_to_shopping': 'أضف كل المكونات للمشتريات',
      'start_timer': 'ابدأ مؤقت',
      'set_timer': 'ظبط وقت التايمر',
      'default_time': 'الوقت الافتراضي',
      'minutes': 'دقيقة',
      'cancel': 'إلغاء',
      'start': 'ابدأ',
      'timer_screen_title': 'مؤقت الطبخ',
      'pause': 'إيقاف مؤقت',
      'resume': 'استئناف',
      'add_5_min': '5 دقائق+',
      'cancel_timer': 'إلغاء المؤقت',
      'counting': 'جاري العد...',
      'stopped': 'متوقف',
      'time_up': '⏰ الوقت انتهى!',
      'time_up_message': 'الخطوة جاهزة الآن. يرجى التحقق من الطعام.',
      'ok': 'تم',
      'settings': 'الإعدادات',
      'language': 'اللغة',
      'theme': 'الوضع',
      'dark_mode': 'الوضع الداكن',
      'arabic': 'العربية',
      'english': 'English',
      'privacy_policy': 'سياسة الخصوصية',
      'privacy_text':
          'تطبيق مطبخي لا يجمع أي بيانات شخصية ولا يرسل أي معلومات إلى أي خادم، ولا يحتوي على إعلانات أو أدوات تتبع.\n\n'
              'يحفظ التطبيق على جهازك فقط: الوصفات المفضلة، وقائمة المشتريات، وإعدادات اللغة والمظهر.\n\n'
              'يطلب التطبيق إذن الإشعارات فقط لتنبيهك عند انتهاء مؤقت الطبخ، ويمكنك إيقافه من إعدادات الهاتف في أي وقت.\n\n'
              'يمكنك حذف كل بيانات التطبيق بحذفه من هاتفك.',
      'notification_title': '⏰ الأكل جاهز!',
      'notification_body': 'الوقت انتهى لخطوة:',
      'edit_time_hint': 'يمكنك تعديل الوقت براحتك حسب كمية الأكل أو درجة النار.',
      'load_error': 'تعذر تحميل الوصفات',
      'nav_recipes': 'الوصفات',
      'nav_meal': 'جدول الوجبات',
      'surprise': 'اقترح أكلة',
      'banner_title': 'أكلة حلوة كل يوم',
      'cat_home': 'منزلي',
      'cat_main': 'أطباق رئيسية',
      'cat_dessert': 'حلويات',
      'cat_baking': 'مخبوزات',
      'cat_breakfast': 'فطور',
      'cat_soups': 'شوربات',
      'cat_salads': 'سلطات ومقبلات',
      'cat_pickles': 'مخللات',
      'meal_plan': 'جدول الوجبات الأسبوعي',
      'meal_hint': 'اختر وصفة لكل يوم من أيام الأسبوع.',
      'no_meal': 'لم يتم اختيار وجبة',
      'clear_meal': 'إزالة الوجبة',
      'clear_all': 'مسح القائمة',
    },
    'en': {
      'app_title': 'Matbakhy',
      'search_hint': 'Search recipe or ingredient...',
      'all': 'All',
      'no_results': 'No results',
      'ingredients': 'Ingredients',
      'steps': 'Instructions',
      'tips': 'Tip',
      'favorites': 'Favorites',
      'no_favorites': 'No favorite recipes yet',
      'shopping_list': 'Shopping List',
      'shopping_empty': 'Your shopping list is empty',
      'add_item_hint': 'Add a new item',
      'clear_checked': 'Remove checked',
      'added_to_shopping': 'Added to shopping list',
      'already_in_shopping': 'Ingredients are already in the list',
      'add_all_to_shopping': 'Add all to shopping list',
      'start_timer': 'Start Timer',
      'set_timer': 'Set Timer',
      'default_time': 'Default time',
      'minutes': 'min',
      'cancel': 'Cancel',
      'start': 'Start',
      'timer_screen_title': 'Cooking Timer',
      'pause': 'Pause',
      'resume': 'Resume',
      'add_5_min': '+5 min',
      'cancel_timer': 'Cancel Timer',
      'counting': 'Counting...',
      'stopped': 'Stopped',
      'time_up': '⏰ Time is up!',
      'time_up_message': 'Step is ready now. Please check the food.',
      'ok': 'OK',
      'settings': 'Settings',
      'language': 'Language',
      'theme': 'Theme',
      'dark_mode': 'Dark mode',
      'arabic': 'العربية',
      'english': 'English',
      'privacy_policy': 'Privacy Policy',
      'privacy_text':
          'Matbakhy does not collect any personal data, does not send any information to any server, and contains no ads or trackers.\n\n'
              'The app stores on your device only: favorite recipes, your shopping list, and language/theme settings.\n\n'
              'The app asks for notification permission only to alert you when a cooking timer ends. You can turn it off in phone settings at any time.\n\n'
              'You can delete all app data by uninstalling the app.',
      'notification_title': '⏰ Food is ready!',
      'notification_body': 'Time is up for step:',
      'edit_time_hint': 'You can adjust the time based on quantity or heat level.',
      'load_error': 'Could not load recipes',
      'nav_recipes': 'Recipes',
      'nav_meal': 'Meal plan',
      'surprise': 'Surprise me',
      'banner_title': 'A delicious idea every day',
      'cat_home': 'Home-style',
      'cat_main': 'Main dishes',
      'cat_dessert': 'Desserts',
      'cat_baking': 'Baking',
      'cat_breakfast': 'Breakfast',
      'cat_soups': 'Soups',
      'cat_salads': 'Salads & starters',
      'cat_pickles': 'Pickles',
      'meal_plan': 'Weekly meal plan',
      'meal_hint': 'Choose one recipe for each day.',
      'no_meal': 'No meal selected',
      'clear_meal': 'Remove meal',
      'clear_all': 'Clear all',
    },
  };

  String translate(String key) => _values[locale.languageCode]?[key] ?? key;
}

class _Delegate extends LocalizationsDelegate<AppLocalizations> {
  const _Delegate();
  @override
  bool isSupported(Locale locale) => ['ar', 'en'].contains(locale.languageCode);
  @override
  Future<AppLocalizations> load(Locale locale) async => AppLocalizations(locale);
  @override
  bool shouldReload(_Delegate old) => false;
}
