import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'localization/app_localizations.dart';
import 'providers/favorites_provider.dart';
import 'providers/meal_plan_provider.dart';
import 'providers/recipes_provider.dart';
import 'providers/settings_provider.dart';
import 'providers/shopping_provider.dart';
import 'screens/home_screen.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService().init();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SettingsProvider()..loadSettings()),
        ChangeNotifierProvider(create: (_) => FavoritesProvider()..loadFavorites()),
        ChangeNotifierProvider(create: (_) => ShoppingProvider()..loadItems()),
        ChangeNotifierProvider(create: (_) => MealPlanProvider()..load()),
        ChangeNotifierProvider(create: (_) => RecipesProvider()..load()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  ThemeData _theme(Brightness b) => ThemeData(
        brightness: b,
        useMaterial3: true,
        colorSchemeSeed: Colors.deepOrange,
        scaffoldBackgroundColor:
            b == Brightness.light ? const Color(0xFFF9F6F2) : const Color(0xFF121212),
        appBarTheme: AppBarTheme(
          backgroundColor: b == Brightness.light ? Colors.deepOrange : const Color(0xFF1F1F1F),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
      );

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      onGenerateTitle: (ctx) => AppLocalizations.of(ctx).translate('app_title'),
      locale: settings.locale,
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: _theme(Brightness.light),
      darkTheme: _theme(Brightness.dark),
      themeMode: settings.themeMode,
      home: const HomeScreen(),
    );
  }
}
