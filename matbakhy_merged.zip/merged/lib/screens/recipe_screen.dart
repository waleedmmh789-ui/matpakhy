import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../localization/app_localizations.dart';
import '../models/recipe.dart';
import '../providers/favorites_provider.dart';
import '../providers/shopping_provider.dart';
import 'home_screen.dart' show isEnglish;
import 'timer_screen.dart';

class RecipeScreen extends StatefulWidget {
  final Recipe recipe;
  const RecipeScreen({super.key, required this.recipe});

  @override
  State<RecipeScreen> createState() => _RecipeScreenState();
}

class _RecipeScreenState extends State<RecipeScreen> {
  final Set<int> _checked = {};

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final en = isEnglish(context);
    final r = widget.recipe;
    final fav = context.watch<FavoritesProvider>();
    final isFav = fav.isFavorite(r.id);
    final meta = [
      '${r.flag} ${r.cuisine(en)}',
      if (r.time(en).isNotEmpty) r.time(en),
      if (r.cost(en).isNotEmpty) r.cost(en),
    ].join('  •  ');
    final tips = r.tips(en);

    return Scaffold(
      appBar: AppBar(
        title: Text(r.title(en), style: const TextStyle(fontSize: 18)),
        actions: [
          IconButton(
            icon: Icon(isFav ? Icons.favorite : Icons.favorite_border, color: Colors.red),
            onPressed: () => fav.toggleFavorite(r.id),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: SizedBox(
              height: 200,
              child: Image.asset(r.image,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const ColoredBox(
                      color: Color(0xFFFFE0B2), child: Center(child: Icon(Icons.restaurant, size: 64)))),
            ),
          ),
          const SizedBox(height: 12),
          Text(r.title(en),
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text(meta),
          if (r.description(en).isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(r.description(en), style: const TextStyle(height: 1.5)),
          ],
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: Text(t.translate('ingredients'),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ),
              Text(en ? 'Serves ${r.servings}' : 'تكفي ${r.servings} أشخاص'),
            ],
          ),
          for (var i = 0; i < r.ingredients.length; i++)
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              activeColor: Colors.deepOrange,
              value: _checked.contains(i),
              title: Text(r.ingredient(i, en)),
              onChanged: (v) => setState(() => v == true ? _checked.add(i) : _checked.remove(i)),
            ),
          const SizedBox(height: 8),
          FilledButton.icon(
            icon: const Icon(Icons.add_shopping_cart),
            label: Text(t.translate('add_all_to_shopping')),
            onPressed: () {
              final n = context.read<ShoppingProvider>().addItems(r.ingredientList(en));
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text(t.translate(n > 0 ? 'added_to_shopping' : 'already_in_shopping')),
                duration: const Duration(seconds: 1),
              ));
            },
          ),
          const SizedBox(height: 18),
          Text(t.translate('steps'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          for (final s in r.steps(en)) _StepCard(step: s),
          if (tips.isNotEmpty)
            Card(
              color: Colors.amber.withValues(alpha: 0.18),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.lightbulb, color: Colors.amber),
                    const SizedBox(width: 8),
                    Expanded(child: Text('${t.translate('tips')}: $tips', style: const TextStyle(height: 1.5))),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _StepCard extends StatelessWidget {
  final RecipeStep step;
  const _StepCard({required this.step});

  void _onTimerPressed(BuildContext context) {
    final t = AppLocalizations.of(context);
    final defaultMinutes = step.minutes ?? 10; // الخطوات بدون وقت واضح تبدأ بـ 10 دقائق وتتعدل
    int selected = defaultMinutes;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: Text(t.translate('set_timer')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('${t.translate('default_time')}: $defaultMinutes ${t.translate('minutes')}',
                  style: const TextStyle(fontSize: 14, color: Colors.grey)),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    onPressed: () {
                      if (selected > 1) setState(() => selected--);
                    },
                    icon: const Icon(Icons.remove_circle_outline),
                  ),
                  Text('$selected ${t.translate('minutes')}',
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  IconButton(
                    onPressed: () => setState(() => selected++),
                    icon: const Icon(Icons.add_circle_outline),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(t.translate('edit_time_hint'),
                  style: const TextStyle(fontSize: 12, color: Colors.grey), textAlign: TextAlign.center),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(t.translate('cancel'))),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepOrange, foregroundColor: Colors.white),
              onPressed: () {
                Navigator.pop(ctx);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => TimerScreen(initialMinutes: selected, stepText: step.text)),
                );
              },
              child: Text(t.translate('start')),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 14,
                  backgroundColor: Colors.deepOrange,
                  child: Text('${step.number}', style: const TextStyle(color: Colors.white, fontSize: 14)),
                ),
                const SizedBox(width: 10),
                Expanded(child: Text(step.text, style: const TextStyle(fontSize: 16, height: 1.5))),
              ],
            ),
            const SizedBox(height: 12),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: ElevatedButton.icon(
                onPressed: () => _onTimerPressed(context),
                icon: const Icon(Icons.timer),
                label: Text(step.minutes != null
                    ? '${t.translate('start_timer')} (${step.minutes} ${t.translate('minutes')})'
                    : t.translate('start_timer')),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepOrange,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
