import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../localization/app_localizations.dart';
import '../providers/settings_provider.dart';
import '../widgets/matbakhy_logo.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final settings = context.watch<SettingsProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(t.translate('settings'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Center(child: MatbakhyLogo(size: 90)),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t.translate('language'),
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  SegmentedButton<String>(
                    segments: [
                      ButtonSegment(value: 'ar', label: Text(t.translate('arabic'))),
                      ButtonSegment(value: 'en', label: Text(t.translate('english'))),
                    ],
                    selected: {settings.locale.languageCode},
                    onSelectionChanged: (s) => settings.changeLanguage(s.first),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: SwitchListTile(
              title: Text(t.translate('dark_mode')),
              value: settings.themeMode == ThemeMode.dark,
              activeColor: Colors.deepOrange,
              onChanged: settings.toggleTheme,
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.privacy_tip),
              title: Text(t.translate('privacy_policy')),
              onTap: () => showDialog(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: Text(t.translate('privacy_policy')),
                  content: SingleChildScrollView(child: Text(t.translate('privacy_text'))),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx), child: Text(t.translate('ok'))),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
