# مطبخي — Matbakhy (Flutter / Android)

تطبيق واحد يدمج «مطبخي» و«سفرتنا اليومية»:
- **358 وصفة**: 32 وصفة مصرية مفصّلة (مع مؤقت لكل خطوة ونصائح) + 326 وصفة من 5 مطابخ عربية (مصري، سوري، خليجي، مغربي، تونسي).
- بحث بالاسم والمكونات، فلترة بالمطبخ والتصنيف، «اقترح أكلة».
- مفضلة، قائمة مشتريات، جدول وجبات أسبوعي، مؤقت طبخ بإشعار لكل خطوة (الوقت يُستخرج من النص تلقائياً، أو 10 دقائق افتراضياً وتعدّله).
- عربي/إنجليزي، فاتح/داكن، سياسة الخصوصية داخل التطبيق.
- يعمل بدون إنترنت. `minSdk 26` · `targetSdk 35` · الحزمة `com.matbakhy.cooking`.

## ملاحظات عن البيانات
- الوصفات المكررة بين التطبيقين: اعتمدت النسخة المفصّلة من «مطبخي» وحذفت القالب العام المقابل من «سفرتنا» (24 وصفة).
- الوصفات الـ32 ليس لها ترجمة إنجليزية للمكونات والخطوات (العنوان فقط)؛ تظهر بالعربي في الواجهة الإنجليزية.
- وصفات «سفرتنا» الـ326 مبنية على قوالب عامة للمكونات والخطوات، وراجع المقادير قبل اعتمادها مرجعاً نهائياً. والصور خمس صور (واحدة لكل مطبخ) مولدة بالذكاء الاصطناعي.
- بيانات المفضلة والمشتريات وجدول الوجبات القديمة في «سفرتنا» تُقرأ تلقائياً من نفس مفاتيح التخزين.

## البناء على GitHub (APK + AAB)
1. ارفع كل محتويات المجلد لريبو GitHub (فرع `main`).
2. `.github/workflows/build.yml` يشتغل تلقائياً، أو من Actions ← Run workflow.
3. حمّل `matbakhy.apk` و`matbakhy.aab` من Artifacts. وعند tag مثل `v1.0.0` يظهران في Releases.

## التوقيع (مهم لـ Google Play)
```
keytool -genkeypair -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
base64 -w0 upload-keystore.jks
```
أضف في Settings ← Secrets and variables ← Actions: `KEYSTORE_BASE64` · `KEYSTORE_PASSWORD` · `KEY_ALIAS` · `KEY_PASSWORD`.
بدونها يولّد الـ workflow مفتاحاً مؤقتاً للتجربة فقط.

## تشغيل محلي
```
flutter create --platforms=android --org com.matbakhy --project-name cooking_app .
flutter pub get && flutter test && flutter run
```

## الأيقونة والشعار
الشعار في `lib/widgets/matbakhy_logo.dart`، والأيقونة في `assets/icon/` (أيقونة كاملة + طبقة أمامية للأيقونة التكيّفية بخلفية `#FF6B35`). تُولَّد ملفات الأيقونة تلقائياً في الـ workflow بـ `flutter_launcher_icons`.

## الصور
كل وصفة تستخدم صورة مطبخها (`assets/images/*.jpg`). لوضع صورة خاصة بوصفة، غيّر حقل `image` لها في `assets/data/recipes.json`.
