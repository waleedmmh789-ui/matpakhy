import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:cooking_app/models/recipe.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('merged recipes load with unique ids', () async {
    final raw = await rootBundle.loadString('assets/data/recipes.json');
    final list = (jsonDecode(raw) as List)
        .map((e) => Recipe.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
    expect(list.length, greaterThan(350));
    expect(list.map((r) => r.id).toSet().length, list.length);
    expect(list.where((r) => r.id.startsWith('matbakhy_')).length, 32);
  });

  test('english falls back to arabic when missing', () {
    final r = Recipe.fromJson({
      'id': 'x', 'titleAr': 'كشري', 'titleEn': '',
      'ingredients': [{'ar': 'أرز', 'en': ''}],
      'stepsAr': ['تُترك 20 دقيقة'], 'stepsEn': [],
    });
    expect(r.title(true), 'كشري');
    expect(r.ingredient(0, true), 'أرز');
    expect(r.steps(true).first.minutes, 20);
  });

  test('detectMinutes', () {
    expect(RecipeStep.detectMinutes('لمدة 3-4 ساعات'), 240);
    expect(RecipeStep.detectMinutes('simmer 15 min'), 15);
    expect(RecipeStep.detectMinutes('يُغسل الأرز'), isNull);
  });
}
