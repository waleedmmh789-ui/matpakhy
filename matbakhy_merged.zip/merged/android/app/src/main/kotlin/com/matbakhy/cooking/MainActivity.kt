package com.matbakhy.cooking

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
