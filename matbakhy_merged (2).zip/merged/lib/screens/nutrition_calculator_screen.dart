import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/premium_provider.dart';
import '../widgets/calc_unlock_button.dart';
import '../localization/app_localizations.dart';
import '../services/nutrition_calculator.dart';
import '../widgets/responsive_body.dart';

class NutritionCalculatorScreen extends StatefulWidget {
  const NutritionCalculatorScreen({super.key});

  @override
  State<NutritionCalculatorScreen> createState() => _NutritionCalculatorScreenState();
}

class _NutritionCalculatorScreenState extends State<NutritionCalculatorScreen> {
  final TextEditingController _controller = TextEditingController();
  final NutritionCalculator _calculator = NutritionCalculator();

  Map<String, dynamic>? _result;
  String? _errorMessage;
  bool _isLoading = true;
  bool _limitReached = false;

  @override
  void initState() {
    super.initState();
    _initCalculator();
  }

  Future<void> _initCalculator() async {
    try {
      await _calculator.loadDatabase();
    } catch (_) {
      _errorMessage = 'تعذر تحميل قاعدة البيانات الغذائية';
    }
    if (mounted) setState(() => _isLoading = false);
  }

  void _calculate() {
    setState(() {
      _errorMessage = null;
      _result = null;
      _limitReached = false;
    });

    if (_controller.text.trim().isEmpty) {
      setState(() => _errorMessage = 'من فضلك اكتب المكون والوزن بالجرام (مثلاً: 250 جرام لحمة)');
      return;
    }

    final premium = context.read<PremiumProvider>();
    if (!premium.canUseCalculator) {
      setState(() => _limitReached = true);
      return;
    }

    try {
      final res = _calculator.calculateNutrition(_controller.text);
      premium.registerCalcUse();
      setState(() => _result = res);
    } catch (e) {
      setState(() => _errorMessage = e.toString().replaceAll('Exception: ', ''));
    }
  }

  void _quickFill(String text) {
    _controller.text = text;
    _calculate();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text(t.translate('nutrition_calculator')),
        centerTitle: true,
      ),
      body: ResponsiveBody(
        child: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.deepOrange))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Text(
                            'اكتب المكون والوزن (بالجرام)',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: isDark ? Colors.white : Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _controller,
                            keyboardType: TextInputType.text,
                            decoration: InputDecoration(
                              hintText: 'مثال: 250 جرام لحمة',
                              filled: true,
                              fillColor: isDark ? Colors.grey[800] : Colors.grey[100],
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide.none,
                              ),
                              prefixIcon: const Icon(Icons.scale, color: Colors.deepOrange),
                            ),
                            onSubmitted: (_) => _calculate(),
                          ),
                          const SizedBox(height: 12),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: _calculate,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.deepOrange,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                              child: const Text(
                                'احسب',
                                style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'اختيارات سريعة:',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white70 : Colors.grey[700],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _buildQuickChip('100 جرام أرز'),
                      _buildQuickChip('200 جرام فراخ'),
                      _buildQuickChip('250 جرام لحمة'),
                      _buildQuickChip('150 جرام عدس'),
                      _buildQuickChip('50 جرام زيت'),
                    ],
                  ),
                  const SizedBox(height: 24),
                  if (_errorMessage != null)
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.red),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.error_outline, color: Colors.red),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _errorMessage!,
                              style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (_limitReached)
                    Card(
                      color: Colors.orange.withOpacity(0.1),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Text(
                              'انتهت عمليات الحساب المجانية اليوم (${PremiumProvider.freeCalcPerDay} يومياً).',
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 10),
                            const CalcUnlockButton(),
                          ],
                        ),
                      ),
                    ),
                  if (_result != null) _buildResultCard(_result!),
                ],
              ),
            ),
      ),
    );
  }

  Widget _buildQuickChip(String label) {
    return ActionChip(
      label: Text(label, style: const TextStyle(fontSize: 12)),
      onPressed: () => _quickFill(label),
      backgroundColor: Theme.of(context).cardColor,
      side: const BorderSide(color: Colors.deepOrange, width: 1),
      labelStyle: const TextStyle(color: Colors.deepOrange),
    );
  }

  Widget _buildResultCard(Map<String, dynamic> result) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: Colors.deepOrange.withOpacity(0.05),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              'النتيجة (${result['ingredient_name']})',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepOrange),
            ),
            const SizedBox(height: 4),
            Text(
              'الوزن: ${(result['weight_grams'] as double).toStringAsFixed(0)} جرام',
              style: const TextStyle(fontSize: 14, color: Colors.grey, fontWeight: FontWeight.bold),
            ),
            const Divider(),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildNutrient('سعرات', (result['calories'] as num).toStringAsFixed(0), 'kcal', Colors.red),
                _buildNutrient('بروتين', (result['protein'] as num).toStringAsFixed(1), 'g', Colors.blue),
                _buildNutrient('كارب', (result['carbs'] as num).toStringAsFixed(1), 'g', Colors.orange),
                _buildNutrient('دهون', (result['fat'] as num).toStringAsFixed(1), 'g', Colors.green),
              ],
            ),
            const SizedBox(height: 10),
            const Text(
              '* الأرقام تقديرية بناءً على متوسط القيم الغذائية لكل 100 جرام (الوزن نيئ ما لم يُذكر "مطبوخ" أو "مسلوق" أو "مشوية").',
              style: TextStyle(fontSize: 10, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNutrient(String label, String value, String unit, Color color) {
    return Column(
      children: [
        Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: color)),
        Text(unit, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
      ],
    );
  }
}
