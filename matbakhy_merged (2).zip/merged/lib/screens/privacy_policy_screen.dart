import 'package:flutter/material.dart';
import '../localization/app_localizations.dart';
import '../widgets/responsive_body.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  static const _sections = <(String, String)>[
    ('مقدمة',
        'تطبيق «مطبخي - وصفات وحاسبة سعرات» يحترم خصوصيتك. توضح هذه السياسة ما الذي يحدث لبياناتك عند استخدام التطبيق.'),
    ('البيانات التي نجمعها',
        'نحن لا نجمع بيانات شخصية بأنفسنا: لا يوجد تسجيل دخول ولا حسابات، ولا نرسل معلومات عنك إلى خوادمنا. وللتوضيح، تتعامل مع بعض البيانات أطراف ثالثة كما هو مبيّن في قسمي «الإعلانات» و«الاشتراك المميز» أدناه.'),
    ('البيانات المخزنة على جهازك فقط',
        'يحفظ التطبيق على جهازك فقط: الوصفات المفضلة، وقائمة المشتريات، وجدول الوجبات، وإعدادات المظهر، والصور التي تختارها لوصفاتك. هذه البيانات لا تغادر جهازك، وتُحذف بحذف التطبيق.'),
        ('الصلاحيات',
        '• الإشعارات: لتنبيهك عند انتهاء مؤقت الطبخ.\n• الكاميرا والصور: لا تُستخدم إلا عندما تضغط على زر الكاميرا لإضافة صورة خاصة بوصفة، والصورة تُحفظ داخل التطبيق على جهازك فقط.'),
    ('الإعلانات',
        'يعرض التطبيق إعلانات عبر Google AdMob (بانر وإعلانات بينية ومكافئة). قد تجمع Google ويستخدم شركاؤها معرّف الإعلانات في جهازك وبيانات عن الجهاز والاستخدام (مثل عنوان IP) لعرض الإعلانات وقياس أدائها ومنع الاحتيال. يمكنك إعادة ضبط معرّف الإعلانات أو إلغاء تخصيص الإعلانات من إعدادات جهازك (الإعدادات ← Google ← الإعلانات). لمعرفة كيف تستخدم Google البيانات: policies.google.com/technologies/partner-sites. المشتركون في النسخة المميزة لا يرون أي إعلانات.'),
    ('الاشتراك المميز',
        'تتم عمليات الدفع والاشتراك بالكامل عبر Google Play، ولا نرى ولا نخزن بيانات بطاقتك. يحتفظ التطبيق على جهازك بحالة الاشتراك فقط (مشترك/غير مشترك). يمكنك إلغاء الاشتراك في أي وقت من Google Play ← المدفوعات والاشتراكات.'),
    ('حاسبة السعرات',
        'القيم الغذائية تقديرية وللمعلومات العامة فقط، ولا تغني عن استشارة الطبيب أو أخصائي التغذية.'),
    ('الأطفال',
        'التطبيق لا يستهدف الأطفال ولا يجمع بيانات منهم عن قصد.'),
    ('التغييرات على السياسة',
        'قد نحدّث هذه السياسة من وقت لآخر، وسيظهر آخر تحديث في أسفل هذه الصفحة.'),
    ('التواصل',
        'لأي استفسار عن الخصوصية راسلنا على: waleedmmh789@gmail.com'),
  ];

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.translate('privacy_policy'))),
      body: ResponsiveBody(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            for (final (title, body) in _sections) ...[
              Text(title,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepOrange)),
              const SizedBox(height: 6),
              Text(body, style: const TextStyle(fontSize: 15, height: 1.7)),
              const SizedBox(height: 18),
            ],
            const Text('آخر تحديث: نوفمبر 2026', style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
