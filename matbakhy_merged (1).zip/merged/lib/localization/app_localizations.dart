import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;
  AppLocalizations(this.locale);

  static AppLocalizations of(BuildContext context) =>
      Localizations.of<AppLocalizations>(context, AppLocalizations)!;

  static const LocalizationsDelegate<AppLocalizations> delegate = _Delegate();

  static const Map<String, Map<String, String>> _values = {
    'ar': {
      'app_title': 'مطبخي',
      'app_label': 'مطبخي - وصفات وحاسبة سعرات',
      'support': 'الدعم والتواصل',
      'search_hint': 'ابحث عن وصفة أو مكون...',
      'all': 'الكل',
      'no_results': 'لا توجد نتائج',
      'ingredients': 'المكونات',
      'steps': 'طريقة التحضير',
      'tips': 'نصيحة',
      'favorites': 'المفضلة',
      'no_favorites': 'لا توجد وصفات مفضلة بعد',
      'shopping_list': 'قائمة المشتريات',
      'shopping_empty': 'قائمة المشتريات فاضية',
      'add_item_hint': 'أضف عنصراً جديداً',
      'clear_checked': 'حذف المشطوب',
      'added_to_shopping': 'تمت الإضافة لقائمة المشتريات',
      'already_in_shopping': 'المكونات موجودة بالفعل في القائمة',
      'add_all_to_shopping': 'أضف كل المكونات للمشتريات',
      'start_timer': 'ابدأ مؤقت',
      'set_timer': 'ظبط وقت التايمر',
      'default_time': 'الوقت الافتراضي',
      'minutes': 'دقيقة',
      'cancel': 'إلغاء',
      'start': 'ابدأ',
      'timer_screen_title': 'مؤقت الطبخ',
      'pause': 'إيقاف مؤقت',
      'resume': 'استئناف',
      'add_5_min': '5 دقائق+',
      'cancel_timer': 'إلغاء المؤقت',
      'counting': 'جاري العد...',
      'stopped': 'متوقف',
      'time_up': '⏰ الوقت انتهى!',
      'time_up_message': 'الخطوة جاهزة الآن. يرجى التحقق من الطعام.',
      'ok': 'تم',
      'settings': 'الإعدادات',
      'theme': 'الوضع',
      'dark_mode': 'الوضع الداكن',
      'privacy_policy': 'سياسة الخصوصية',
      'notification_title': '⏰ الأكل جاهز!',
      'notification_body': 'الوقت انتهى لخطوة:',
      'edit_time_hint': 'يمكنك تعديل الوقت براحتك حسب كمية الأكل أو درجة النار.',
      'load_error': 'تعذر تحميل الوصفات',
      'nav_recipes': 'الوصفات',
      'nav_meal': 'جدول الوجبات',
      'surprise': 'اقترح أكلة',
      'banner_title': 'أكلة حلوة كل يوم',
      'cat_home': 'منزلي',
      'cat_main': 'أطباق رئيسية',
      'cat_dessert': 'حلويات',
      'cat_baking': 'مخبوزات',
      'cat_breakfast': 'فطور',
      'cat_soups': 'شوربات',
      'cat_salads': 'سلطات ومقبلات',
      'cat_pickles': 'مخللات',
      'cat_heritage': 'أكلات تراثية',
      'nutrition_calculator': 'حاسبة السعرات',
      'meal_plan': 'جدول الوجبات الأسبوعي',
      'meal_hint': 'اختر وصفة لكل يوم من أيام الأسبوع.',
      'no_meal': 'لم يتم اختيار وجبة',
      'clear_meal': 'إزالة الوجبة',
      'clear_all': 'مسح القائمة',
    },
  };

  String translate(String key) => _values[locale.languageCode]?[key] ?? key;
}

class _Delegate extends LocalizationsDelegate<AppLocalizations> {
  const _Delegate();
  @override
  bool isSupported(Locale locale) => locale.languageCode == 'ar';
  @override
  Future<AppLocalizations> load(Locale locale) async => AppLocalizations(locale);
  @override
  bool shouldReload(_Delegate old) => false;
}
