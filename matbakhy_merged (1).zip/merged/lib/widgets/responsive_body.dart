import 'package:flutter/material.dart';

/// يحمي المحتوى من شريط التنقل/الحواف (Edge-to-Edge) ويحدد أقصى عرض
/// عشان الشاشات الكبيرة (تابلت) ما يتمططش عليها المحتوى.
class ResponsiveBody extends StatelessWidget {
  final Widget child;
  final double maxWidth;
  final bool safeBottom;
  const ResponsiveBody({
    super.key,
    required this.child,
    this.maxWidth = 720,
    this.safeBottom = true,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false, // الـ AppBar بيتعامل مع الشريط العلوي
      bottom: safeBottom,
      child: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: maxWidth),
          child: child,
        ),
      ),
    );
  }
}
