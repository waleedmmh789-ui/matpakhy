import 'package:flutter/material.dart';
import 'dart:math' as math;

class MatbakhyLogo extends StatelessWidget {
  final double size;
  final bool showText;
  final Color? primaryColor;
  final Color? secondaryColor;

  const MatbakhyLogo({
    super.key,
    this.size = 120,
    this.showText = true,
    this.primaryColor,
    this.secondaryColor,
  });

  @override
  Widget build(BuildContext context) {
    final orange = primaryColor ?? const Color(0xFFFF6B35);
    final green = secondaryColor ?? const Color(0xFF4CAF50);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: size,
          height: size,
          child: CustomPaint(
            painter: _LogoPainter(orange: orange, green: green),
          ),
        ),
        if (showText) ...[
          const SizedBox(height: 12),
          Text(
            'مطبخي',
            style: TextStyle(
              fontSize: size * 0.22,
              fontWeight: FontWeight.bold,
              color: orange,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            'Matbakhy',
            style: TextStyle(
              fontSize: size * 0.13,
              fontWeight: FontWeight.w600,
              color: orange.withValues(alpha: 0.7),
              letterSpacing: 2,
            ),
          ),
        ],
      ],
    );
  }
}

class _LogoPainter extends CustomPainter {
  final Color orange;
  final Color green;

  _LogoPainter({required this.orange, required this.green});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    // 1. الخلفية الدائرية (Gradient)
    final bgPaint = Paint()
      ..shader = LinearGradient(
        colors: [orange, orange.withValues(alpha: 0.6)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.drawCircle(center, radius, bgPaint);

    // 2. الحلة (Pot)
    final potPaint = Paint()..color = Colors.white;
    final potWidth = size.width * 0.5;
    final potHeight = size.height * 0.3;
    final potRect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(center.dx, center.dy + size.height * 0.1),
        width: potWidth,
        height: potHeight,
      ),
      Radius.circular(potHeight * 0.3),
    );
    canvas.drawRRect(potRect, potPaint);

    // 3. أيدي الحلة
    final handlePaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.04
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCenter(
        center: Offset(center.dx - potWidth / 2, center.dy + size.height * 0.1),
        width: size.width * 0.12,
        height: size.height * 0.15,
      ),
      math.pi * 0.5,
      math.pi,
      false,
      handlePaint,
    );

    canvas.drawArc(
      Rect.fromCenter(
        center: Offset(center.dx + potWidth / 2, center.dy + size.height * 0.1),
        width: size.width * 0.12,
        height: size.height * 0.15,
      ),
      -math.pi * 0.5,
      math.pi,
      false,
      handlePaint,
    );

    // 4. الغطاء
    final lidPaint = Paint()..color = green;
    final lidRect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(center.dx, center.dy - size.height * 0.05),
        width: potWidth * 0.85,
        height: size.height * 0.05,
      ),
      Radius.circular(size.height * 0.025),
    );
    canvas.drawRRect(lidRect, lidPaint);

    // 5. مقبض الغطاء
    canvas.drawCircle(
      Offset(center.dx, center.dy - size.height * 0.1),
      size.width * 0.035,
      Paint()..color = green,
    );

    // 6. البخار (يتحول لقلب)
    final heartPaint = Paint()..color = green;
    final heartCenter = Offset(center.dx, center.dy - size.height * 0.25);
    final heartSize = size.width * 0.06;
    final heartPath = Path();

    heartPath.moveTo(heartCenter.dx, heartCenter.dy + heartSize * 0.3);
    heartPath.cubicTo(
      heartCenter.dx - heartSize, heartCenter.dy,
      heartCenter.dx - heartSize, heartCenter.dy - heartSize,
      heartCenter.dx, heartCenter.dy - heartSize * 0.5,
    );
    heartPath.cubicTo(
      heartCenter.dx + heartSize, heartCenter.dy - heartSize,
      heartCenter.dx + heartSize, heartCenter.dy,
      heartCenter.dx, heartCenter.dy + heartSize * 0.3,
    );
    canvas.drawPath(heartPath, heartPaint);
  }

  @override
  bool shouldRepaint(_LogoPainter oldDelegate) =>
      oldDelegate.orange != orange || oldDelegate.green != green;
}
