import 'dart:convert';
import 'package:flutter/services.dart';

/// حاسبة القيم الغذائية بالجرام فقط. القيم في القاعدة لكل 100 جرام.
class NutritionCalculator {
  Map<String, dynamic> _database = {};
  List<String> _keysLongestFirst = [];

  Future<void> loadDatabase() async {
    final String jsonString = await rootBundle.loadString('assets/data/nutrition_db.json');
    _setDatabase(json.decode(jsonString) as Map<String, dynamic>);
  }

  void _setDatabase(Map<String, dynamic> db) {
    _database = db;
    // الأطول أولاً حتى يفوز "أرز مطبوخ" على "أرز".
    _keysLongestFirst = db.keys.toList()..sort((a, b) => b.length.compareTo(a.length));
  }

  static const _arabicDigits = '٠١٢٣٤٥٦٧٨٩';

  String _normalize(String s) {
    final b = StringBuffer();
    for (final ch in s.split('')) {
      final i = _arabicDigits.indexOf(ch);
      b.write(i >= 0 ? '$i' : ch);
    }
    return b.toString().replaceAll('٫', '.').replaceAll(RegExp(r'[\u064B-\u0652]'), '').trim();
  }

  Map<String, dynamic> calculateNutrition(String rawInput) {
    final input = _normalize(rawInput);

    if (RegExp(r'كيلو|كوب|ملعقة|ملعقه|رطل').hasMatch(input)) {
      throw Exception('الحاسبة بالجرام فقط. اكتب الوزن بالجرام، مثلاً: "250 جرام لحمة".');
    }

    final quantityInGrams = _parseQuantity(input);
    if (quantityInGrams <= 0) {
      throw Exception('عذراً، لم أفهم الوزن. جرب تكتب "250 جرام" أو "500 جرام".');
    }

    final ingredientName = _parseIngredient(input);
    if (!_database.containsKey(ingredientName)) {
      final shown = ingredientName.isEmpty ? 'المكون' : ingredientName;
      throw Exception('عذراً، المكون "$shown" غير موجود في قاعدة بياناتنا.');
    }

    final data = _database[ingredientName] as Map<String, dynamic>;
    final factor = quantityInGrams / 100.0;

    return {
      'ingredient_name': ingredientName,
      'weight_grams': quantityInGrams,
      'calories': (data['calories'] as num) * factor,
      'protein': (data['protein'] as num) * factor,
      'carbs': (data['carbs'] as num) * factor,
      'fat': (data['fat'] as num) * factor,
    };
  }

  double _parseQuantity(String input) {
    final match = RegExp(r'(\d+(\.\d+)?)').firstMatch(input);
    if (match != null && match.group(1) != null) {
      return double.parse(match.group(1)!);
    }
    return 0;
  }

  String _parseIngredient(String input) {
    for (final key in _keysLongestFirst) {
      if (input.contains(key)) return key;
    }
    return input
        .replaceAll(RegExp(r'\d+(\.\d+)?'), '')
        .replaceAll('جرام', '')
        .replaceAll('غرام', '')
        .replaceAll('جم', '')
        .trim();
  }
}
