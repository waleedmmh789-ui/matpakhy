import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// إدارة صور المستخدم الخاصة بالوصفات.
/// الصورة تُنسخ إلى مجلد التطبيق (لأن ملف الكاميرا/المعرض المؤقت قد يُحذف)،
/// ويُحفظ مسارها في SharedPreferences بمفتاح لكل وصفة.
class ImageManager {
  ImageManager._();

  static final ImagePicker _picker = ImagePicker();
  static String _key(String id) => 'user_image_$id';

  /// يفتح الكاميرا أو المعرض ويرجع مسار الملف المؤقت، أو null لو المستخدم ألغى.
  static Future<String?> pickImage(ImageSource source) async {
    final x = await _picker.pickImage(
      source: source,
      maxWidth: 1600,
      imageQuality: 80,
    );
    return x?.path;
  }

  /// ينسخ الصورة لمجلد التطبيق ويحفظ مسارها للوصفة [id]، ويرجع المسار النهائي.
  static Future<String> saveUserImage(String id, String path) async {
    final prefs = await SharedPreferences.getInstance();
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'user_images'));
    if (!await dir.exists()) await dir.create(recursive: true);

    final ext = p.extension(path).isEmpty ? '.jpg' : p.extension(path);
    // اسم فريد حتى لا تُعرض نسخة قديمة من كاش Flutter بعد تغيير الصورة.
    final dest = p.join(dir.path, '${id}_${DateTime.now().millisecondsSinceEpoch}$ext');
    await File(path).copy(dest);

    final old = prefs.getString(_key(id));
    await prefs.setString(_key(id), dest);
    if (old != null && old != dest) _deleteQuietly(old);
    return dest;
  }

  /// مسار صورة المستخدم للوصفة [id] لو موجودة، وإلا null.
  static Future<String?> getUserImage(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString(_key(id));
    if (path == null) return null;
    if (await File(path).exists()) return path;
    await prefs.remove(_key(id)); // الملف اتمسح من برة التطبيق
    return null;
  }

  /// يمسح الصورة المخصصة ويرجّع الوصفة لصورتها الأصلية.
  static Future<void> removeUserImage(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString(_key(id));
    await prefs.remove(_key(id));
    if (path != null) _deleteQuietly(path);
  }

  static void _deleteQuietly(String path) {
    try {
      final f = File(path);
      if (f.existsSync()) f.deleteSync();
    } catch (_) {}
  }
}
