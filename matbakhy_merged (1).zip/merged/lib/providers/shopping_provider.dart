import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ShoppingItem {
  final String name;
  bool isChecked;
  ShoppingItem({required this.name, this.isChecked = false});

  Map<String, dynamic> toJson() => {'name': name, 'checked': isChecked};
  factory ShoppingItem.fromJson(Map<String, dynamic> j) =>
      ShoppingItem(name: j['name'] as String, isChecked: j['checked'] == true);
}

class ShoppingProvider extends ChangeNotifier {
  List<ShoppingItem> _items = [];
  List<ShoppingItem> get items => _items;

  Future<void> loadItems() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('shopping_items');
      if (raw != null) {
        _items = (jsonDecode(raw) as List)
            .map((e) => ShoppingItem.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
      }
    } catch (_) {
      _items = [];
    }
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('shopping_items', jsonEncode(_items.map((e) => e.toJson()).toList()));
  }

  /// يرجع عدد العناصر التي أُضيفت فعلاً (بدون تكرار).
  int addItems(List<String> names) {
    var added = 0;
    for (final name in names) {
      final n = name.trim();
      if (n.isNotEmpty && !_items.any((e) => e.name == n)) {
        _items.add(ShoppingItem(name: n));
        added++;
      }
    }
    _save();
    notifyListeners();
    return added;
  }

  void addItem(String name) {
    if (name.trim().isEmpty) return;
    _items.add(ShoppingItem(name: name.trim()));
    _save();
    notifyListeners();
  }

  void toggleItem(int i) {
    _items[i].isChecked = !_items[i].isChecked;
    _save();
    notifyListeners();
  }

  void removeItem(int i) {
    _items.removeAt(i);
    _save();
    notifyListeners();
  }

  void clearAll() {
    _items.clear();
    _save();
    notifyListeners();
  }

  void clearChecked() {
    _items.removeWhere((e) => e.isChecked);
    _save();
    notifyListeners();
  }
}
