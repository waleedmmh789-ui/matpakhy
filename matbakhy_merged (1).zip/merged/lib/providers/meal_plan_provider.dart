import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// اليوم 0 = السبت ... 6 = الجمعة (نفس الترتيب في العربي والإنجليزي).
class MealPlanProvider extends ChangeNotifier {
  final Map<int, String> _plan = {};
  String? mealFor(int day) => _plan[day];

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    for (var i = 0; i < 7; i++) {
      final id = prefs.getString('meal_$i');
      if (id != null) _plan[i] = id;
    }
    notifyListeners();
  }

  Future<void> setMeal(int day, String? recipeId) async {
    final prefs = await SharedPreferences.getInstance();
    if (recipeId == null) {
      _plan.remove(day);
      await prefs.remove('meal_$day');
    } else {
      _plan[day] = recipeId;
      await prefs.setString('meal_$day', recipeId);
    }
    notifyListeners();
  }
}
