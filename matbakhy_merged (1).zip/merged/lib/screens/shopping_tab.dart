import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../localization/app_localizations.dart';
import '../providers/shopping_provider.dart';

class ShoppingTab extends StatefulWidget {
  const ShoppingTab({super.key});

  @override
  State<ShoppingTab> createState() => _ShoppingTabState();
}

class _ShoppingTabState extends State<ShoppingTab> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _add(ShoppingProvider s) {
    s.addItem(_controller.text);
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final shopping = context.watch<ShoppingProvider>();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _controller,
                  decoration: InputDecoration(
                      hintText: t.translate('add_item_hint'), border: const OutlineInputBorder()),
                  onSubmitted: (_) => _add(shopping),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: () => _add(shopping), icon: const Icon(Icons.add)),
            ],
          ),
        ),
        Expanded(
          child: shopping.items.isEmpty
              ? Center(child: Text(t.translate('shopping_empty')))
              : ListView.builder(
                  itemCount: shopping.items.length,
                  itemBuilder: (context, i) {
                    final item = shopping.items[i];
                    return CheckboxListTile(
                      title: Text(item.name,
                          style: TextStyle(
                              decoration: item.isChecked ? TextDecoration.lineThrough : null)),
                      value: item.isChecked,
                      onChanged: (_) => shopping.toggleItem(i),
                      secondary: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => shopping.removeItem(i),
                      ),
                    );
                  },
                ),
        ),
        if (shopping.items.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Wrap(
              spacing: 8,
              children: [
                TextButton.icon(
                  onPressed: shopping.clearChecked,
                  icon: const Icon(Icons.delete_sweep),
                  label: Text(t.translate('clear_checked')),
                ),
                TextButton.icon(
                  onPressed: shopping.clearAll,
                  icon: const Icon(Icons.clear_all),
                  label: Text(t.translate('clear_all')),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
