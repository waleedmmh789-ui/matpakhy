import 'package:flutter/material.dart';
import '../localization/app_localizations.dart';
import '../widgets/responsive_body.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  static const _sections = <(String, String)>[
    ('مقدمة',
        'تطبيق «مطبخي - وصفات وحاسبة سعرات» يحترم خصوصيتك. توضح هذه السياسة ما الذي يحدث لبياناتك عند استخدام التطبيق.'),
    ('البيانات التي نجمعها',
        'لا نجمع أي بيانات شخصية. لا يوجد تسجيل دخول ولا حسابات، ولا نرسل أي معلومات عنك إلى خوادمنا.'),
    ('البيانات المخزنة على جهازك فقط',
        'يحفظ التطبيق على جهازك فقط: الوصفات المفضلة، وقائمة المشتريات، وجدول الوجبات، وإعدادات المظهر، والصور التي تختارها لوصفاتك. هذه البيانات لا تغادر جهازك، وتُحذف بحذف التطبيق.'),
        ('الصلاحيات',
        '• الإشعارات: لتنبيهك عند انتهاء مؤقت الطبخ.\n• الكاميرا والصور: لا تُستخدم إلا عندما تضغط على زر الكاميرا لإضافة صورة خاصة بوصفة، والصورة تُحفظ داخل التطبيق على جهازك فقط.'),
    ('الإعلانات',
        'لا يعرض التطبيق إعلانات حاليًا. وإذا أضيفت إعلانات في إصدار لاحق، فقد تستخدم شبكات الإعلانات معرّفات الجهاز (مثل معرّف الإعلانات) لعرض إعلانات مناسبة وقياس أدائها، وسنحدّث هذه السياسة قبل ذلك ونوفر لك خيارات التحكم المتاحة.'),
    ('حاسبة السعرات',
        'القيم الغذائية تقديرية وللمعلومات العامة فقط، ولا تغني عن استشارة الطبيب أو أخصائي التغذية.'),
    ('الأطفال',
        'التطبيق لا يستهدف الأطفال ولا يجمع بيانات منهم عن قصد.'),
    ('التغييرات على السياسة',
        'قد نحدّث هذه السياسة من وقت لآخر، وسيظهر آخر تحديث في أسفل هذه الصفحة.'),
    ('التواصل',
        'لأي استفسار عن الخصوصية راسلنا على: waleedmmh789@gmail.com'),
  ];

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.translate('privacy_policy'))),
      body: ResponsiveBody(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            for (final (title, body) in _sections) ...[
              Text(title,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepOrange)),
              const SizedBox(height: 6),
              Text(body, style: const TextStyle(fontSize: 15, height: 1.7)),
              const SizedBox(height: 18),
            ],
            const Text('آخر تحديث: نوفمبر 2026', style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
