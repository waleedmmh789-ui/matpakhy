import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../localization/app_localizations.dart';
import '../widgets/matbakhy_logo.dart';
import '../widgets/responsive_body.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  static const supportEmail = 'waleedmmh789@gmail.com';

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.translate('support'))),
      body: ResponsiveBody(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Center(child: MatbakhyLogo(size: 90)),
            const SizedBox(height: 12),
            Center(
              child: Text(t.translate('app_label'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 20),
            const Text(
              'لأي استفسار أو اقتراح أو مشكلة في التطبيق، تواصل معنا على البريد الإلكتروني:',
              style: TextStyle(fontSize: 15, height: 1.6),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.email, color: Colors.deepOrange),
                title: const SelectableText(supportEmail),
                subtitle: const Text('اضغط للنسخ'),
                trailing: const Icon(Icons.copy),
                onTap: () async {
                  await Clipboard.setData(const ClipboardData(text: supportEmail));
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('تم نسخ البريد الإلكتروني'), duration: Duration(seconds: 1)),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
