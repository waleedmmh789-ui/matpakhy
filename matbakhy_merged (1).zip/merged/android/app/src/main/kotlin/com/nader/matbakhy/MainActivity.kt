package com.nader.matbakhy

import android.os.Bundle
import androidx.core.view.WindowCompat
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // عرض من الحافة للحافة (Edge-to-Edge) على كل إصدارات أندرويد.
        // enableEdgeToEdge() تحتاج ComponentActivity، و FlutterActivity مش كده،
        // فنستخدم WindowCompat وهي نفس النتيجة.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)
    }
}
