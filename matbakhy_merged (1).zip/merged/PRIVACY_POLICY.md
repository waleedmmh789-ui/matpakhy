# سياسة الخصوصية — مطبخي / Privacy Policy — Matbakhy

**العربية:** تطبيق «مطبخي» لا يجمع أي بيانات شخصية، ولا يرسل أي معلومات إلى أي خادم، ولا يحتوي على إعلانات أو أدوات تتبع. يحفظ التطبيق على جهازك فقط: الوصفات المفضلة، وقائمة المشتريات، وإعدادات اللغة والمظهر. يطلب إذن الإشعارات فقط لتنبيهك عند انتهاء مؤقت الطبخ. يمكنك حذف كل البيانات بحذف التطبيق.

**English:** Matbakhy does not collect any personal data, does not send information to any server, and has no ads or trackers. It stores on your device only your favorite recipes, shopping list, and language/theme settings. Notification permission is used only to alert you when a cooking timer ends. Uninstalling the app deletes all data.

(Replace this note with the public URL of this file on GitHub when you submit to Google Play: `https://github.com/<USER>/<REPO>/blob/main/PRIVACY_POLICY.md`)
