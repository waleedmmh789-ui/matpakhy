import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// معرّف منتج الاشتراك السنوي — لازم يطابق Product ID في Google Play Console.
const String kPremiumProductId = 'matbakhy_premium_yearly';

/// معرّف الاشتراك الشهري — اشتراك منفصل في Play Console.
const String kMonthlyProductId = 'matbakhy_premium_monthly';

/// كل المنتجات التي تفتح النسخة المميزة.
const Set<String> kPremiumProductIds = {kPremiumProductId, kMonthlyProductId};

/// السعر الاحتياطي الشهري الظاهر لو تعذر جلب السعر من المتجر.
const String kMonthlyPriceLabel = '\$1.99 / شهر';

/// السعر الاحتياطي الظاهر لو تعذر جلب السعر من المتجر. عدّله براحتك.
const String kYearlyPriceLabel = '\$9.99 / سنة';

/// حالة الاشتراك + حدود حاسبة السعرات (مفتوحة للمشتركين أو بعد مشاهدة إعلان مكافئ).
class PremiumProvider extends ChangeNotifier {
  /// عدد مرات استخدام الحاسبة المجانية يومياً قبل ظهور خيار الإعلان المكافئ.
  static const int freeCalcPerDay = 3;

  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  bool _loaded = false;
  bool _isPremium = false;
  bool _storeAvailable = false;
  bool _busy = false;
  bool _startupCheck = false;
  String? _message;
  ProductDetails? _yearly;
  ProductDetails? _monthly;

  int _calcUnlockedUntil = 0; // millisSinceEpoch
  int _calcUses = 0;
  String _calcDay = '';

  bool get loaded => _loaded;
  bool get isPremium => _isPremium;
  bool get storeAvailable => _storeAvailable;
  bool get busy => _busy;
  String? get message => _message;
  ProductDetails? get yearlyProduct => _yearly;
  ProductDetails? get monthlyProduct => _monthly;
  bool get hasProducts => _yearly != null || _monthly != null;

  String get yearlyPriceLabel => _yearly != null ? '${_yearly!.price} / سنة' : kYearlyPriceLabel;
  String get monthlyPriceLabel => _monthly != null ? '${_monthly!.price} / شهر' : kMonthlyPriceLabel;

  /// نسبة التوفير للسنوي مقارنةً بـ 12 شهراً (للعرض فقط)، أو null لو غير متاحة.
  int? get yearlySavingPercent {
    if (_yearly == null || _monthly == null) return null;
    final y = _yearly!.rawPrice, m = _monthly!.rawPrice * 12;
    if (m <= 0 || y >= m) return null;
    return ((1 - y / m) * 100).round();
  }

  bool get calcUnlocked => DateTime.now().millisecondsSinceEpoch < _calcUnlockedUntil;
  bool get canUseCalculator => _isPremium || calcUnlocked || _usesToday < freeCalcPerDay;
  int get _usesToday => _calcDay == _today() ? _calcUses : 0;
  int get remainingFreeCalcs => (freeCalcPerDay - _usesToday).clamp(0, freeCalcPerDay);

  static String _today() {
    final n = DateTime.now();
    return '${n.year}-${n.month}-${n.day}';
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _isPremium = prefs.getBool('isPremiumUser') ?? false;
    _calcUnlockedUntil = prefs.getInt('calc_unlocked_until') ?? 0;
    _calcUses = prefs.getInt('calc_uses') ?? 0;
    _calcDay = prefs.getString('calc_day') ?? '';
    _loaded = true;
    notifyListeners();
    await _initStore();
  }

  Future<void> _initStore() async {
    try {
      _sub = _iap.purchaseStream.listen(_onPurchases, onError: (_) {});
      _storeAvailable = await _iap.isAvailable();
      if (!_storeAvailable) {
        notifyListeners();
        return;
      }
      final res = await _iap.queryProductDetails(kPremiumProductIds);
      for (final d in res.productDetails) {
        if (d.id == kPremiumProductId) _yearly = d;
        if (d.id == kMonthlyProductId) _monthly = d;
      }
      notifyListeners();
      // تحقق صامت من الاشتراك عند الإقلاع (يلتقط الانتهاء/الإلغاء لو المتجر ردّ).
      _startupCheck = true;
      await _iap.restorePurchases();
    } catch (_) {
      _storeAvailable = false;
      notifyListeners();
    }
  }

  Future<void> _setPremium(bool v) async {
    if (_isPremium == v) return;
    _isPremium = v;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isPremiumUser', v);
  }

  Future<void> _onPurchases(List<PurchaseDetails> list) async {
    var foundActive = false;
    for (final p in list) {
      if (kPremiumProductIds.contains(p.productID)) {
        switch (p.status) {
          case PurchaseStatus.pending:
            _busy = true;
            break;
          case PurchaseStatus.purchased:
          case PurchaseStatus.restored:
            foundActive = true;
            _busy = false;
            _message = null;
            await _setPremium(true);
            break;
          case PurchaseStatus.error:
            _busy = false;
            _message = 'تعذر إتمام الشراء. حاول مرة أخرى.';
            break;
          case PurchaseStatus.canceled:
            _busy = false;
            break;
        }
      }
      if (p.pendingCompletePurchase) await _iap.completePurchase(p);
    }
    if (_startupCheck) {
      _startupCheck = false;
      // رد المتجر على الاستعادة ما فيهوش اشتراك فعّال → الاشتراك انتهى/اتلغى.
      if (!foundActive && list.every((p) => p.status != PurchaseStatus.pending)) {
        await _setPremium(false);
      }
    }
    notifyListeners();
  }

  /// شراء اشتراك ([kPremiumProductId] سنوي أو [kMonthlyProductId] شهري).
  Future<void> buy(String productId) async {
    final product = productId == kMonthlyProductId ? _monthly : _yearly;
    if (product == null || _busy) return;
    _message = null;
    _busy = true;
    notifyListeners();
    try {
      await _iap.buyNonConsumable(purchaseParam: PurchaseParam(productDetails: product));
    } catch (_) {
      _busy = false;
      _message = 'تعذر بدء عملية الشراء.';
      notifyListeners();
    }
  }

  /// استعادة المشتريات (إجباري من جوجل).
  Future<void> restore() async {
    if (!_storeAvailable || _busy) return;
    _message = null;
    _busy = true;
    notifyListeners();
    try {
      await _iap.restorePurchases();
    } catch (_) {
      _message = 'تعذر استعادة المشتريات.';
    }
    // لو ما وصلش رد خلال ثوانٍ نفك حالة الانتظار ونبلّغ المستخدم.
    Future.delayed(const Duration(seconds: 6), () {
      if (_busy) {
        _busy = false;
        _message ??= _isPremium ? null : 'لم نجد اشتراكاً فعّالاً على هذا الحساب.';
        notifyListeners();
      }
    });
  }

  // ---- حاسبة السعرات ----
  Future<void> registerCalcUse() async {
    if (_isPremium || calcUnlocked) return;
    final today = _today();
    if (_calcDay != today) {
      _calcDay = today;
      _calcUses = 0;
    }
    _calcUses++;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('calc_day', _calcDay);
    await prefs.setInt('calc_uses', _calcUses);
  }

  /// مكافأة الإعلان: فتح الحاسبة 24 ساعة.
  Future<void> unlockCalculator24h() async {
    _calcUnlockedUntil = DateTime.now().add(const Duration(hours: 24)).millisecondsSinceEpoch;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('calc_unlocked_until', _calcUnlockedUntil);
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
