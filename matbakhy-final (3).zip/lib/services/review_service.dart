import 'package:flutter/material.dart';
import 'package:in_app_review/in_app_review.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// طلب تقييم التطبيق على Google Play بشكل غير مزعج.
///
/// - لا يظهر عند أول فتح؛ فقط بعد "إنجاز مفيد" (حفظ وصفة في المفضلة أو مشاركتها).
/// - شروط الظهور: 3 إنجازات على الأقل، ومرور يومين من أول استخدام، وفاصل 14 يوماً بين كل ظهور،
///   وحد أقصى 3 مرات، ولا يظهر بعد أن يضغط المستخدم "قيّم التطبيق الآن".
/// - لا نطلب تقييماً إيجابياً بعينه، ولا نقدم أي مكافأة مقابل التقييم (سياسة Google Play).
/// - نافذة التقييم الرسمية تُعرض عبر Play In-App Review API (ReviewManager)، وإن لم تتوفر
///   نفتح صفحة التطبيق على Google Play كبديل. Google هي من تقرر ظهور النافذة فعلاً (حصة محدودة).
class ReviewService {
  ReviewService._();

  static const _kFirstUse = 'review_first_use_ms';
  static const _kActions = 'review_positive_actions';
  static const _kLastPrompt = 'review_last_prompt_ms';
  static const _kShown = 'review_shown_count';
  static const _kLater = 'review_later_count';
  static const _kDone = 'review_done';

  static const int minActions = 3;
  static const int minDaysSinceFirstUse = 2;
  static const int cooldownDays = 14;
  static const int maxPrompts = 3;

  static const Duration _day = Duration(days: 1);
  static bool _busy = false;

  /// يُستدعى عند الإقلاع لتسجيل تاريخ أول استخدام.
  static Future<void> touchFirstUse() async {
    final prefs = await SharedPreferences.getInstance();
    if (!prefs.containsKey(_kFirstUse)) {
      await prefs.setInt(_kFirstUse, DateTime.now().millisecondsSinceEpoch);
    }
  }

  /// يُستدعى بعد إنجاز مفيد (حفظ وصفة / مشاركتها). قد يعرض الشاشة التمهيدية إن تحققت الشروط.
  static Future<void> registerPositiveAction(BuildContext context) async {
    if (_busy) return;
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now().millisecondsSinceEpoch;

    if (!prefs.containsKey(_kFirstUse)) await prefs.setInt(_kFirstUse, now);
    final first = prefs.getInt(_kFirstUse) ?? now;
    final actions = (prefs.getInt(_kActions) ?? 0) + 1;
    await prefs.setInt(_kActions, actions);

    if (prefs.getBool(_kDone) ?? false) return;
    if ((prefs.getInt(_kShown) ?? 0) >= maxPrompts) return;
    if (actions < minActions) return;
    if (now - first < _day.inMilliseconds * minDaysSinceFirstUse) return;
    final last = prefs.getInt(_kLastPrompt) ?? 0;
    if (last != 0 && now - last < _day.inMilliseconds * cooldownDays) return;
    if (!context.mounted) return;

    _busy = true;
    try {
      // نسجل الوقت عند الظهور (وليس فقط عند "لاحقاً") حتى لا تتكرر الشاشة سريعاً.
      await prefs.setInt(_kLastPrompt, now);
      await prefs.setInt(_kShown, (prefs.getInt(_kShown) ?? 0) + 1);

      final rateNow = await showDialog<bool>(
        context: context,
        builder: (_) => const _ReviewPrePrompt(),
      );

      if (rateNow == true) {
        await prefs.setBool(_kDone, true);
        await _launchReview();
      } else {
        await prefs.setInt(_kLater, (prefs.getInt(_kLater) ?? 0) + 1);
      }
    } finally {
      _busy = false;
    }
  }

  static Future<void> _launchReview() async {
    final review = InAppReview.instance;
    try {
      if (await review.isAvailable()) {
        await review.requestReview(); // نافذة Google Play الرسمية (ReviewManager)
      } else {
        await review.openStoreListing(); // بديل: صفحة التطبيق على Google Play
      }
    } catch (_) {
      try {
        await review.openStoreListing();
      } catch (_) {}
    }
  }
}

/// الشاشة التمهيدية قبل نافذة التقييم الرسمية.
class _ReviewPrePrompt extends StatelessWidget {
  const _ReviewPrePrompt();

  static const _orange = Color(0xFFFF6B35);

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 28, 24, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: _orange.withValues(alpha: 0.35),
                    blurRadius: 18,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: Image.asset('assets/icon/icon.png', width: 88, height: 88, fit: BoxFit.cover),
              ),
            ),
            const SizedBox(height: 18),
            const Text('رأيك يهمنا',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(
              'هل استمتعت باستخدام «مطبخي - وصفات وحاسبة سعرات»؟ '
              'تقييمك على Google Play يساعدنا على التطوير وإضافة وصفات أكثر.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, height: 1.7, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 22),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: _orange,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: () => Navigator.pop(context, true),
                child: const Text('قيّم التطبيق الآن',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 4),
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('لاحقاً'),
            ),
          ],
        ),
      ),
    );
  }
}
