import 'package:flutter/foundation.dart';

/// معرفات وحدات AdMob.
/// في وضع التطوير (debug) نستخدم وحدات الاختبار الرسمية من جوجل، لأن الضغط على
/// إعلاناتك الحقيقية أثناء التجربة قد يؤدي لإيقاف حساب AdMob. في الـ release
/// تُستخدم وحداتك الحقيقية تلقائياً.
class AdConfig {
  AdConfig._();

  static const _bannerReal = 'ca-app-pub-9932315898148137/6940696210';
  static const _interstitialReal = 'ca-app-pub-9932315898148137/2955103767';
  static const _rewardedReal = 'ca-app-pub-9932315898148137/9622699879';

  /// وحدة مكافأة (Rewarded) ثانية — احتياطية وغير مستخدمة حالياً.
  static const reservedRewarded = 'ca-app-pub-9932315898148137/2763532075';

  static const _bannerTest = 'ca-app-pub-3940256099942544/6300978111';
  static const _interstitialTest = 'ca-app-pub-3940256099942544/1033173712';
  static const _rewardedTest = 'ca-app-pub-3940256099942544/5224354917';

  static String get banner => kDebugMode ? _bannerTest : _bannerReal;
  static String get interstitial => kDebugMode ? _interstitialTest : _interstitialReal;
  static String get rewarded => kDebugMode ? _rewardedTest : _rewardedReal;
}
