import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../providers/premium_provider.dart';
import 'ad_config.dart';

/// كل استدعاءات الإعلانات تمر من هنا، وكلها تتحقق أولاً من isPremiumUser:
/// المشترك لا يرى أي إعلان (بانر/بيني/مكافئ) نهائياً.
class AdService {
  AdService._();
  static final AdService instance = AdService._();

  /// الإعلان البيني يظهر مرة كل N مرات فتح وصفة.
  static const int interstitialEvery = 3;

  PremiumProvider? _premium;
  InterstitialAd? _interstitial;
  RewardedAd? _rewarded;
  bool _loadingInterstitial = false;
  bool _loadingRewarded = false;

  /// القاعدة الذهبية: لا إعلانات قبل تحميل حالة الاشتراك، ولا للمشتركين.
  bool get canShowAds => _premium != null && _premium!.loaded && !_premium!.isPremium;

  void attach(PremiumProvider premium) {
    _premium = premium;
    premium.addListener(_onPremiumChanged);
  }

  void _onPremiumChanged() {
    if (canShowAds) {
      _loadInterstitial();
      _loadRewarded();
    } else {
      _interstitial?.dispose();
      _interstitial = null;
      _rewarded?.dispose();
      _rewarded = null;
    }
  }

  // ---------- Interstitial ----------
  void _loadInterstitial() {
    if (!canShowAds || _interstitial != null || _loadingInterstitial) return;
    _loadingInterstitial = true;
    InterstitialAd.load(
      adUnitId: AdConfig.interstitial,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _loadingInterstitial = false;
          if (canShowAds) {
            _interstitial = ad;
          } else {
            ad.dispose();
          }
        },
        onAdFailedToLoad: (e) {
          _loadingInterstitial = false;
          debugPrint('Interstitial failed: $e');
        },
      ),
    );
  }

  /// يُستدعى عند فتح وصفة. يعدّ المرات (محفوظ في SharedPreferences) ويعرض
  /// الإعلان مرة كل [interstitialEvery]، ثم ينفّذ [proceed] (فتح الوصفة) مرة واحدة.
  Future<void> maybeShowInterstitial(VoidCallback proceed) async {
    if (!canShowAds) {
      proceed();
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final opens = (prefs.getInt('recipe_open_count') ?? 0) + 1;
    await prefs.setInt('recipe_open_count', opens);

    final ad = _interstitial;
    if (opens % interstitialEvery == 0 && ad != null && canShowAds) {
      _interstitial = null;
      var done = false;
      void go() {
        if (done) return;
        done = true;
        proceed();
      }

      ad.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (a) {
          a.dispose();
          _loadInterstitial();
          go();
        },
        onAdFailedToShowFullScreenContent: (a, e) {
          a.dispose();
          _loadInterstitial();
          go();
        },
      );
      ad.show();
    } else {
      if (ad == null) _loadInterstitial();
      proceed();
    }
  }

  // ---------- Rewarded ----------
  void _loadRewarded() {
    if (!canShowAds || _rewarded != null || _loadingRewarded) return;
    _loadingRewarded = true;
    RewardedAd.load(
      adUnitId: AdConfig.rewarded,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _loadingRewarded = false;
          if (canShowAds) {
            _rewarded = ad;
          } else {
            ad.dispose();
          }
        },
        onAdFailedToLoad: (e) {
          _loadingRewarded = false;
          debugPrint('Rewarded failed: $e');
        },
      ),
    );
  }

  /// يعرض الإعلان المكافئ؛ يستدعي [onReward] فقط لو المستخدم أكمل المشاهدة،
  /// و[onUnavailable] لو الإعلان غير جاهز.
  void showRewarded({required VoidCallback onReward, required VoidCallback onUnavailable}) {
    final ad = _rewarded;
    if (!canShowAds || ad == null) {
      _loadRewarded();
      onUnavailable();
      return;
    }
    _rewarded = null;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (a) {
        a.dispose();
        _loadRewarded();
      },
      onAdFailedToShowFullScreenContent: (a, e) {
        a.dispose();
        _loadRewarded();
        onUnavailable();
      },
    );
    ad.show(onUserEarnedReward: (_, __) => onReward());
  }
}
