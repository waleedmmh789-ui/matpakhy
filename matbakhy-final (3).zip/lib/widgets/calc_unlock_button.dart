import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../ads/ad_service.dart';
import '../providers/premium_provider.dart';

/// زر الإعلان المكافئ: «شاهد إعلاناً لاستخدام الحاسبة بدون قيود» (24 ساعة).
/// مخفي للمشتركين ولمن فتح الحاسبة بالفعل.
class CalcUnlockButton extends StatelessWidget {
  const CalcUnlockButton({super.key});

  @override
  Widget build(BuildContext context) {
    final premium = context.watch<PremiumProvider>();
    if (!premium.loaded || premium.isPremium || premium.calcUnlocked) {
      return const SizedBox.shrink();
    }
    return OutlinedButton.icon(
      icon: const Icon(Icons.play_circle_outline),
      label: const Text('شاهد إعلاناً لاستخدام الحاسبة بدون قيود (24 ساعة)'),
      style: OutlinedButton.styleFrom(foregroundColor: Colors.deepOrange),
      onPressed: () {
        final messenger = ScaffoldMessenger.of(context);
        AdService.instance.showRewarded(
          onReward: () {
            premium.unlockCalculator24h();
            messenger.showSnackBar(const SnackBar(
              content: Text('تم فتح حاسبة السعرات بدون قيود لمدة 24 ساعة 🎉'),
            ));
          },
          onUnavailable: () => messenger.showSnackBar(const SnackBar(
            content: Text('الإعلان غير جاهز الآن، حاول بعد قليل.'),
          )),
        );
      },
    );
  }
}
