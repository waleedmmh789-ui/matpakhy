import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';

import 'ads/ad_service.dart';
import 'providers/premium_provider.dart';

import 'localization/app_localizations.dart';
import 'providers/favorites_provider.dart';
import 'providers/meal_plan_provider.dart';
import 'providers/recipes_provider.dart';
import 'providers/settings_provider.dart';
import 'providers/shopping_provider.dart';
import 'screens/home_screen.dart';
import 'services/notification_service.dart';
import 'services/review_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // عرض من الحافة للحافة (مطلوب في أندرويد 15+)
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  // تهيئة الإعلانات فور الإقلاع (بدون انتظار، حتى لا نؤخر الشاشة الأولى)
  MobileAds.instance.initialize();
  await NotificationService().init();
  ReviewService.touchFirstUse(); // تاريخ أول استخدام (لتوقيت طلب التقييم)
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SettingsProvider()..loadSettings()),
        ChangeNotifierProvider(
        lazy: false,
        create: (_) {
          final p = PremiumProvider()..load();
          AdService.instance.attach(p);
          return p;
        }),
        ChangeNotifierProvider(create: (_) => FavoritesProvider()..loadFavorites()),
        ChangeNotifierProvider(create: (_) => ShoppingProvider()..loadItems()),
        ChangeNotifierProvider(create: (_) => MealPlanProvider()..load()),
        ChangeNotifierProvider(create: (_) => RecipesProvider()..load()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  ThemeData _theme(Brightness b) => ThemeData(
        brightness: b,
        useMaterial3: true,
        colorSchemeSeed: Colors.deepOrange,
        scaffoldBackgroundColor:
            b == Brightness.light ? const Color(0xFFF9F6F2) : const Color(0xFF121212),
        appBarTheme: AppBarTheme(
          backgroundColor: b == Brightness.light ? Colors.deepOrange : const Color(0xFF1F1F1F),
          foregroundColor: Colors.white,
          elevation: 0,
          systemOverlayStyle: SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
            statusBarIconBrightness: Brightness.light, // الـ AppBar دايماً غامق
            statusBarBrightness: Brightness.dark,
            systemNavigationBarColor: Colors.transparent,
            systemNavigationBarDividerColor: Colors.transparent,
            systemNavigationBarContrastEnforced: false,
            systemNavigationBarIconBrightness:
                b == Brightness.light ? Brightness.dark : Brightness.light,
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      onGenerateTitle: (ctx) => AppLocalizations.of(ctx).translate('app_label'),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: _theme(Brightness.light),
      darkTheme: _theme(Brightness.dark),
      themeMode: settings.themeMode,
      home: const HomeScreen(),
    );
  }
}
