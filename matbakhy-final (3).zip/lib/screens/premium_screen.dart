import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/premium_provider.dart';
import '../widgets/responsive_body.dart';

class PremiumScreen extends StatefulWidget {
  const PremiumScreen({super.key});

  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {
  String _selected = kPremiumProductId; // السنوي افتراضياً (الأوفر)

  @override
  Widget build(BuildContext context) {
    final premium = context.watch<PremiumProvider>();
    final canBuy = premium.storeAvailable &&
        !premium.busy &&
        (_selected == kMonthlyProductId ? premium.monthlyProduct : premium.yearlyProduct) != null;
    final saving = premium.yearlySavingPercent;

    return Scaffold(
      appBar: AppBar(title: const Text('الاشتراك المميز')),
      body: ResponsiveBody(
        maxWidth: 560,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 8),
            const Center(child: Text('👑', style: TextStyle(fontSize: 64))),
            const SizedBox(height: 8),
            const Center(
              child: Text('ترقية للنسخة الممتازة',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.deepOrange)),
            ),
            const SizedBox(height: 24),
            const _Feature(icon: Icons.block, text: 'تصفح بدون إعلانات نهائياً'),
            const _Feature(icon: Icons.calculate, text: 'حاسبة السعرات بدون قيود'),
            const _Feature(icon: Icons.favorite, text: 'دعم استمرار التطبيق وتطويره'),
            const SizedBox(height: 24),
            if (premium.isPremium)
              Card(
                color: Colors.green.withOpacity(0.12),
                child: const Padding(
                  padding: EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Icon(Icons.verified, color: Colors.green),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text('أنت مشترك في النسخة المميزة. شكراً لدعمك! ✨',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                ),
              )
            else ...[
              _PlanCard(
                title: 'اشتراك سنوي',
                price: premium.yearlyPriceLabel,
                badge: saving != null ? 'وفّر $saving%' : 'الأوفر',
                selected: _selected == kPremiumProductId,
                onTap: () => setState(() => _selected = kPremiumProductId),
              ),
              const SizedBox(height: 10),
              _PlanCard(
                title: 'اشتراك شهري',
                price: premium.monthlyPriceLabel,
                selected: _selected == kMonthlyProductId,
                onTap: () => setState(() => _selected = kMonthlyProductId),
              ),
              const SizedBox(height: 14),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: Colors.deepOrange,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                onPressed: canBuy ? () => premium.buy(_selected) : null,
                child: premium.busy
                    ? const SizedBox(
                        height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('اشترك الآن (إزالة الإعلانات)',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              ),
              if (!premium.storeAvailable || !premium.hasProducts)
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Text('متجر جوجل بلاي غير متاح حالياً أو المنتجات غير مُعرَّفة بعد.',
                      textAlign: TextAlign.center, style: TextStyle(color: Colors.grey, fontSize: 12)),
                ),
            ],
            const SizedBox(height: 8),
            TextButton(
              onPressed: (premium.busy || !premium.storeAvailable) ? null : premium.restore,
              child: const Text('استعادة المشتريات'),
            ),
            if (premium.message != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(premium.message!,
                    textAlign: TextAlign.center, style: const TextStyle(color: Colors.red)),
              ),
            const SizedBox(height: 16),
            const Text(
              'الاشتراك يتجدد تلقائياً (كل شهر أو كل سنة حسب الخطة التي تختارها) ما لم تلغِه قبل موعد التجديد '
              'بـ 24 ساعة على الأقل. يُحاسَب الحساب على Google Play عند تأكيد الشراء، ويمكنك إدارة الاشتراك '
              'أو إلغاؤه في أي وقت من Google Play ← المدفوعات والاشتراكات ← الاشتراكات.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: Colors.grey, height: 1.6),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final String title;
  final String price;
  final String? badge;
  final bool selected;
  final VoidCallback onTap;
  const _PlanCard({
    required this.title,
    required this.price,
    required this.selected,
    required this.onTap,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? Colors.deepOrange : Colors.grey.shade400, width: selected ? 2 : 1),
          color: selected ? Colors.deepOrange.withOpacity(0.08) : null,
        ),
        child: Row(
          children: [
            Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off,
                color: selected ? Colors.deepOrange : Colors.grey),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      if (badge != null) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                              color: Colors.green, borderRadius: BorderRadius.circular(10)),
                          child: Text(badge!,
                              style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(price, style: const TextStyle(fontSize: 18)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Feature extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Feature({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, color: Colors.deepOrange),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }
}
